import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:lpg_diag/comm/simulator_transport.dart';
import 'package:lpg_diag/core/models/finding.dart';
import 'package:lpg_diag/core/models/telemetry.dart';
import 'package:lpg_diag/diagnostics/fault_engine.dart';
import 'package:lpg_diag/protocol/ecu_protocol.dart';

List<Telemetry> run(SimFault fault, {double seconds = 60}) {
  final m = EcuSimModel(fault: fault);
  return [for (var i = 1; i <= seconds * 10; i++) m.sample(i / 10)];
}

void main() {
  group('protocol', () {
    test('round trip through fragmented, noisy stream', () {
      final t = EcuSimModel().sample(5);
      final frame = encodeTelemetry(t);
      final parser = FrameParser();
      final noisy = Uint8List.fromList([0x00, 0xAA, 0x13, ...frame, ...frame]);
      final out = <EcuFrame>[];
      for (var i = 0; i < noisy.length; i += 3) {
        out.addAll(parser.feed(
            noisy.sublist(i, (i + 3).clamp(0, noisy.length).toInt())));
      }
      expect(out.length, 2);
      final d = decodeTelemetry(out.first.payload)!;
      expect(d.rpm, t.rpm);
      expect(d.gasMapKpa, closeTo(t.gasMapKpa, 0.06));
      expect(d.gasInjectorMs.length, 4);
    });

    test('bad CRC is rejected and counted', () {
      final frame = encodeTelemetry(EcuSimModel().sample(1));
      frame[frame.length - 1] ^= 0xFF;
      final p = FrameParser();
      expect(p.feed(frame), isEmpty);
      expect(p.crcErrors, greaterThan(0));
    });
  });

  group('fault engine', () {
    final engine = FaultEngine();

    String? top(SimFault f) {
      final r = engine.analyze(run(f));
      final real = r.findings.where((x) => x.severity != Severity.info);
      return real.isEmpty ? null : real.first.id;
    }

    test('healthy system has no faults', () => expect(top(SimFault.none), isNull));
    test('clogged filter', () => expect(top(SimFault.cloggedFilter), 'filter_clogged'));
    test('faulty reducer', () => expect(top(SimFault.faultyReducer), 'reducer_unstable'));
    test('cold reducer', () => expect(top(SimFault.coldReducer), 'reducer_cold'));
    test('injector 2', () => expect(top(SimFault.restrictedInjector2), 'injector_dev_1'));
    test('sensor open', () => expect(top(SimFault.gasSensorOpen), 'gas_map_sensor'));

    test('too little data', () {
      final r = engine.analyze(run(SimFault.none, seconds: 1));
      expect(r.status, ReportStatus.insufficientData);
    });
  });
}
