# Android setup

Create the platform folders once, then copy `lib/` and `test/` in:

```bash
flutter create --org com.example --project-name lpg_diag --platforms android .
flutter pub get
```

## 1. AndroidManifest.xml (`android/app/src/main/AndroidManifest.xml`)

Add inside `<manifest>` (before `<application>`):

```xml
<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
<uses-permission android:name="android.permission.BLUETOOTH_SCAN"
                 android:usesPermissionFlags="neverForLocation"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30"/>
<uses-feature android:name="android.hardware.usb.host" android:required="false"/>
<uses-feature android:name="android.hardware.bluetooth" android:required="false"/>
```

Add inside the main `<activity>` so Android offers the app when a USB adapter is plugged in:

```xml
<intent-filter>
    <action android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED"/>
</intent-filter>
<meta-data android:name="android.hardware.usb.action.USB_DEVICE_ATTACHED"
           android:resource="@xml/device_filter"/>
```

Copy `android_snippets/device_filter.xml` to `android/app/src/main/res/xml/device_filter.xml`.

## 2. minSdk

In `android/app/build.gradle(.kts)` set `minSdk = 21` (or higher).

## 3. flutter_bluetooth_serial and newer Gradle

`flutter_bluetooth_serial` 0.4.0 is unmaintained. With Android Gradle Plugin 8+ it may fail with
"Namespace not specified". Fixes: add `namespace 'io.github.edufolly.flutterbluetoothserial'`
to the plugin's `android/build.gradle` in your pub cache, or switch to a maintained fork. Only
`lib/comm/bluetooth_transport.dart` and the Bluetooth tab in `connect_screen.dart` depend on it.
