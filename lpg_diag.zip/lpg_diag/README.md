# LPG/CNG ECU Diagnostics (Flutter, Android)

## Architecture

```
lib/
  main.dart                      app + provider wiring
  comm/
    ecu_transport.dart           abstract byte pipe (connect / write / input stream)
    bluetooth_transport.dart     flutter_bluetooth_serial (SPP)
    usb_transport.dart           usb_serial (OTG)
    simulator_transport.dart     EcuSimModel + fake ECU emitting real frames
  protocol/
    ecu_protocol.dart            frame format, CRC8, resync parser, encode/decode
  core/models/                   Telemetry, Finding, DiagnosticReport
  diagnostics/
    stats.dart                   mean / std / median / linear regression
    fault_engine.dart            rule-based fault localisation
  services/ecu_service.dart      ChangeNotifier: link state, history, analysis loop
  ui/                            theme, connect screen, dashboard (Live / Charts / Diagnosis)
```

Data flow: `Transport.input` -> `FrameParser.feed` -> `decodeTelemetry` -> `EcuService.history`
-> (every 2 s) `FaultEngine.analyze(window)` -> `DiagnosticReport` -> UI.

## Wire protocol (placeholder: adapt to your ECU)

`AA 55 | LEN | CMD | PAYLOAD | CRC8(LEN,CMD,PAYLOAD)`, little endian. Commercial gas ECUs
(STAG, BRC, Zenit, Landi Renzo, KME ...) use proprietary protocols. Only
`protocol/ecu_protocol.dart` knows the wire format, so supporting a real ECU means rewriting
`Cmd`, `decodeTelemetry`, `buildFrame` (and the handshake in `EcuService.connect`). If you have a
protocol spec or a capture, that is the file to change. Use the Simulator tab until then.

## Fault logic (diagnostics/fault_engine.dart)

Key signals: gas rail overpressure `ΔP = gasMAP - manifoldMAP` and injector duty
`duty% = t_ms * rpm / 1200`. Samples are split into an idle bucket and a high-load bucket,
and a regression of ΔP against duty gives a residual that load cannot explain.

| Symptom | Conclusion |
|---|---|
| ΔP fine at idle, falls ≥18 % with load, smooth, reducer warm | Clogged gas filter |
| ΔP scatter (residual σ ≥ 12 kPa) independent of load | Reducer unstable (diaphragm/valve) |
| Idle ΔP above 140 kPa | Reducer over-pressure |
| Idle ΔP below 60 kPa and flat across load | Reducer under-pressure |
| Reducer < 35 °C on gas (+ load drop) | Heating circuit / icing; filter rule suppressed |
| One injector's time ≠ sibling median by ≥12 %, consistently | That injector restricted (high) or rich (low) |
| One injector ≈ 0 ms | Injector / wiring open circuit |
| Gas MAP railed or frozen | Sensor fault; pressure rules suppressed |
| ΔP < 10 kPa at idle | No gas flow (tank, valve, solenoid) |

Injector rules compare each injector with the per-sample median, which removes everything
common to all cylinders (pressure, load, global trim). That is why a supply problem and a
single-injector problem do not get confused. Thresholds live in `FaultThresholds`; calibrate
per vehicle/reducer before trusting results on real cars.

## Run

See `ANDROID_SETUP.md`, then `flutter run`. `flutter test` runs the protocol and fault-engine
tests against the simulator scenarios.

## Ideas for next steps

Session recording to CSV, per-ECU protocol plugins behind a `ProtocolDriver` interface,
adjustable thresholds in a settings screen, PDF report export.
