import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

class GaugeZone {
  const GaugeZone(this.from, this.to, this.color);
  final double from;
  final double to;
  final Color color;
}

/// 270° arc gauge with coloured zones and a big numeric read-out.
class ArcGauge extends StatelessWidget {
  const ArcGauge({
    super.key,
    required this.label,
    required this.unit,
    required this.value,
    required this.min,
    required this.max,
    this.zones = const [],
    this.decimals = 0,
  });

  final String label;
  final String unit;
  final double? value;
  final double min;
  final double max;
  final List<GaugeZone> zones;
  final int decimals;

  Color _colorFor(double v) {
    for (final z in zones) {
      if (v >= z.from && v <= z.to) return z.color;
    }
    return AppColors.accent;
  }

  @override
  Widget build(BuildContext context) {
    final v = value;
    final color = v == null ? AppColors.textDim : _colorFor(v);
    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned.fill(
          child: CustomPaint(
            painter: _GaugePainter(
                value: v, min: min, max: max, zones: zones, color: color),
          ),
        ),
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 14),
            FittedBox(
              child: Text(
                v == null ? '--' : v.toStringAsFixed(decimals),
                style: TextStyle(
                    color: color,
                    fontSize: 34,
                    fontWeight: FontWeight.w700,
                    fontFeatures: const [FontFeature.tabularFigures()]),
              ),
            ),
            Text(unit,
                style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ],
    );
  }
}

class _GaugePainter extends CustomPainter {
  _GaugePainter({
    required this.value,
    required this.min,
    required this.max,
    required this.zones,
    required this.color,
  });

  final double? value;
  final double min;
  final double max;
  final List<GaugeZone> zones;
  final Color color;

  static const double _start = 0.75 * math.pi;
  static const double _sweep = 1.5 * math.pi;

  @override
  void paint(Canvas canvas, Size size) {
    final side = math.min(size.width, size.height);
    final stroke = side * 0.075;
    final rect = Rect.fromCenter(
      center: size.center(Offset.zero),
      width: side - stroke,
      height: side - stroke,
    );

    final track = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.butt
      ..color = Colors.white10;
    canvas.drawArc(rect, _start, _sweep, false, track);

    // zone hints (thin ring just inside)
    final inner = rect.deflate(stroke * 0.9);
    final zonePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke * 0.25;
    for (final z in zones) {
      final a = ((z.from - min) / (max - min)).clamp(0.0, 1.0);
      final b = ((z.to - min) / (max - min)).clamp(0.0, 1.0);
      zonePaint.color = z.color.withValues(alpha: 0.55);
      canvas.drawArc(inner, _start + _sweep * a, _sweep * (b - a), false, zonePaint);
    }

    final v = value;
    if (v == null) return;
    final frac = ((v - min) / (max - min)).clamp(0.0, 1.0);
    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..color = color;
    canvas.drawArc(rect, _start, _sweep * frac, false, arc);
  }

  @override
  bool shouldRepaint(covariant _GaugePainter old) =>
      old.value != value || old.color != color || old.max != max;
}
