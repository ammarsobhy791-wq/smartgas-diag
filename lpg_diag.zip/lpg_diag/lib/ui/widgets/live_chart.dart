import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../theme.dart';
import 'panel.dart';

class ChartSeries {
  const ChartSeries(this.label, this.values, this.color);
  final String label;
  final List<double> values;
  final Color color;
}

/// Scrolling line chart over the most recent samples (index = sample number).
class LiveChart extends StatelessWidget {
  const LiveChart({
    super.key,
    required this.title,
    required this.unit,
    required this.series,
    this.minY,
    this.maxY,
    this.height = 170,
  });

  final String title;
  final String unit;
  final List<ChartSeries> series;
  final double? minY;
  final double? maxY;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 14)),
              const SizedBox(width: 6),
              Text(unit,
                  style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
              const Spacer(),
              for (final s in series) ...[
                Container(
                    width: 8,
                    height: 8,
                    decoration:
                        BoxDecoration(color: s.color, shape: BoxShape.circle)),
                const SizedBox(width: 4),
                Text(s.label,
                    style:
                        const TextStyle(color: AppColors.textDim, fontSize: 11)),
                const SizedBox(width: 8),
              ],
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: height,
            child: LineChart(
              LineChartData(
                minY: minY,
                maxY: maxY,
                lineTouchData: const LineTouchData(enabled: false),
                borderData: FlBorderData(show: false),
                gridData: FlGridData(
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (_) =>
                      const FlLine(color: Colors.white10, strokeWidth: 1),
                ),
                titlesData: const FlTitlesData(
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles:
                      AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles:
                      AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(showTitles: true, reservedSize: 40),
                  ),
                ),
                lineBarsData: [
                  for (final s in series)
                    LineChartBarData(
                      spots: [
                        for (var i = 0; i < s.values.length; i++)
                          FlSpot(i.toDouble(), s.values[i])
                      ],
                      color: s.color,
                      barWidth: 2,
                      isCurved: false,
                      dotData: const FlDotData(show: false),
                    ),
                ],
              ),
              duration: Duration.zero,
            ),
          ),
        ],
      ),
    );
  }
}
