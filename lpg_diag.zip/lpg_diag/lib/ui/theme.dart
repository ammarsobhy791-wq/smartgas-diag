import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0B0F14);
  static const surface = Color(0xFF111820);
  static const card = Color(0xFF17202A);
  static const border = Color(0x1FFFFFFF);
  static const accent = Color(0xFF00E5A0);
  static const info = Color(0xFF4DA3FF);
  static const warn = Color(0xFFFFB020);
  static const danger = Color(0xFFFF4D4F);
  static const textDim = Color(0xFF8A99A8);

  static const series = [
    Color(0xFF00E5A0),
    Color(0xFF4DA3FF),
    Color(0xFFFFB020),
    Color(0xFFFF6B9A),
    Color(0xFFB388FF),
    Color(0xFF64FFDA),
  ];
}

ThemeData buildDarkTheme() {
  const scheme = ColorScheme.dark(
    primary: AppColors.accent,
    secondary: AppColors.info,
    surface: AppColors.surface,
    error: AppColors.danger,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.surface,
      elevation: 0,
      centerTitle: false,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.surface,
      indicatorColor: AppColors.accent.withValues(alpha: 0.18),
    ),
    fontFamily: 'Roboto',
  );
}
