import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/models/finding.dart';
import '../../core/models/telemetry.dart';
import '../../services/ecu_service.dart';
import '../theme.dart';
import '../widgets/arc_gauge.dart';
import '../widgets/live_chart.dart';
import '../widgets/panel.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<EcuService>();
    final issues = svc.report.findings
        .where((f) => f.severity != Severity.info)
        .length;

    return Scaffold(
      appBar: AppBar(
        title: Text(svc.deviceName ?? 'ECU', overflow: TextOverflow.ellipsis),
        actions: [
          if (svc.isStale)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Icon(Icons.signal_wifi_connected_no_internet_4,
                  color: AppColors.warn),
            ),
          IconButton(
            tooltip: 'Clear history',
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: svc.clearHistory,
          ),
          IconButton(
            tooltip: 'Disconnect',
            icon: const Icon(Icons.link_off),
            onPressed: svc.disconnect,
          ),
        ],
      ),
      body: IndexedStack(
        index: _index,
        children: const [_LivePage(), _ChartsPage(), _DiagnosisPage()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          const NavigationDestination(
              icon: Icon(Icons.speed), label: 'Live'),
          const NavigationDestination(
              icon: Icon(Icons.show_chart), label: 'Charts'),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: issues > 0,
              label: Text('$issues'),
              child: const Icon(Icons.troubleshoot),
            ),
            label: 'Diagnosis',
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- Live page

class _LivePage extends StatelessWidget {
  const _LivePage();

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<EcuService>();
    final t = svc.latest;
    final cols = MediaQuery.of(context).size.width > 700 ? 4 : 2;

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        _StatusRow(t: t, stale: svc.isStale, crc: svc.crcErrors),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: cols,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: [
            Panel(
              child: ArcGauge(
                label: 'GAS MAP',
                unit: 'kPa',
                value: t?.gasMapKpa,
                min: 0,
                max: 300,
                zones: const [
                  GaugeZone(0, 50, AppColors.danger),
                  GaugeZone(50, 260, AppColors.accent),
                  GaugeZone(260, 300, AppColors.warn),
                ],
              ),
            ),
            Panel(
              child: ArcGauge(
                label: 'GAS ΔP (vs MAP)',
                unit: 'kPa',
                value: t?.pressureDeltaKpa,
                min: 0,
                max: 200,
                zones: const [
                  GaugeZone(0, 60, AppColors.danger),
                  GaugeZone(60, 140, AppColors.accent),
                  GaugeZone(140, 200, AppColors.warn),
                ],
              ),
            ),
            Panel(
              child: ArcGauge(
                label: 'REDUCER TEMP',
                unit: '°C',
                value: t?.reducerTempC,
                min: 0,
                max: 120,
                decimals: 1,
                zones: const [
                  GaugeZone(0, 35, AppColors.info),
                  GaugeZone(35, 90, AppColors.accent),
                  GaugeZone(90, 120, AppColors.danger),
                ],
              ),
            ),
            Panel(
              child: ArcGauge(
                label: 'ENGINE RPM',
                unit: 'rpm',
                value: t?.rpm.toDouble(),
                min: 0,
                max: 7000,
                zones: const [
                  GaugeZone(0, 5500, AppColors.accent),
                  GaugeZone(5500, 6500, AppColors.warn),
                  GaugeZone(6500, 7000, AppColors.danger),
                ],
              ),
            ),
          ],
        ),
        const SectionTitle('Gas injector timing'),
        Panel(
          child: _InjectorBars(
            times: t?.gasInjectorMs ?? const [],
            flagged: svc.report.flaggedInjectors,
          ),
        ),
        const SizedBox(height: 12),
        Panel(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _Stat('Petrol inj', '${(t?.petrolInjectorMs ?? 0).toStringAsFixed(2)} ms'),
              _Stat('Duty', '${(t?.dutyPercent ?? 0).toStringAsFixed(1)} %'),
              _Stat('Battery', '${(t?.batteryV ?? 0).toStringAsFixed(1)} V'),
            ],
          ),
        ),
      ],
    );
  }
}

class _StatusRow extends StatelessWidget {
  const _StatusRow({required this.t, required this.stale, required this.crc});
  final Telemetry? t;
  final bool stale;
  final int crc;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (t?.mode) {
      FuelMode.gas => ('GAS', AppColors.accent),
      FuelMode.petrol => ('PETROL', AppColors.info),
      FuelMode.switching => ('SWITCHING', AppColors.warn),
      _ => ('NO DATA', AppColors.textDim),
    };
    return Row(
      children: [
        Chip(
          label: Text(label,
              style: TextStyle(color: color, fontWeight: FontWeight.w700)),
          side: BorderSide(color: color),
          backgroundColor: color.withValues(alpha: 0.12),
        ),
        const SizedBox(width: 8),
        if (stale)
          const Chip(
            label: Text('No data > 3 s'),
            backgroundColor: Color(0x33FFB020),
          ),
        const Spacer(),
        Text('CRC errors: $crc',
            style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(
        children: [
          Text(value,
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          Text(label,
              style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
        ],
      );
}

class _InjectorBars extends StatelessWidget {
  const _InjectorBars({required this.times, required this.flagged});
  final List<double> times;
  final Set<int> flagged;

  @override
  Widget build(BuildContext context) {
    if (times.isEmpty) {
      return const Text('—', style: TextStyle(color: AppColors.textDim));
    }
    const maxMs = 14.0;
    return Column(
      children: [
        for (var i = 0; i < times.length; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              children: [
                SizedBox(
                  width: 52,
                  child: Text('INJ ${i + 1}',
                      style: TextStyle(
                          color: flagged.contains(i)
                              ? AppColors.danger
                              : AppColors.textDim,
                          fontWeight: FontWeight.w600,
                          fontSize: 12)),
                ),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: (times[i] / maxMs).clamp(0.0, 1.0),
                      minHeight: 10,
                      backgroundColor: Colors.white10,
                      color: flagged.contains(i)
                          ? AppColors.danger
                          : AppColors.series[i % AppColors.series.length],
                    ),
                  ),
                ),
                SizedBox(
                  width: 64,
                  child: Text('${times[i].toStringAsFixed(2)} ms',
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                          fontFeatures: [FontFeature.tabularFigures()])),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

// -------------------------------------------------------------- Charts page

class _ChartsPage extends StatelessWidget {
  const _ChartsPage();

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<EcuService>();
    final h = svc.history;
    final w = h.length > 300 ? h.sublist(h.length - 300) : h.toList();
    final nInj = w.isEmpty ? 0 : w.last.gasInjectorMs.length;

    List<double> col(double Function(Telemetry t) f) => [for (final t in w) f(t)];

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        LiveChart(
          title: 'Pressure',
          unit: 'kPa',
          series: [
            ChartSeries('Gas MAP', col((t) => t.gasMapKpa), AppColors.accent),
            ChartSeries('Manifold', col((t) => t.manifoldMapKpa), AppColors.info),
          ],
        ),
        const SizedBox(height: 12),
        LiveChart(
          title: 'Gas ΔP',
          unit: 'kPa',
          series: [
            ChartSeries('ΔP', col((t) => t.pressureDeltaKpa), AppColors.warn),
          ],
        ),
        const SizedBox(height: 12),
        LiveChart(
          title: 'Engine speed',
          unit: 'rpm',
          series: [
            ChartSeries('RPM', col((t) => t.rpm.toDouble()), AppColors.accent),
          ],
        ),
        const SizedBox(height: 12),
        LiveChart(
          title: 'Reducer temperature',
          unit: '°C',
          series: [
            ChartSeries('Temp', col((t) => t.reducerTempC), AppColors.info),
          ],
        ),
        const SizedBox(height: 12),
        LiveChart(
          title: 'Injector timings',
          unit: 'ms',
          series: [
            for (var i = 0; i < nInj; i++)
              ChartSeries(
                '#${i + 1}',
                col((t) => i < t.gasInjectorMs.length ? t.gasInjectorMs[i] : 0),
                AppColors.series[i % AppColors.series.length],
              ),
          ],
        ),
      ],
    );
  }
}

// ----------------------------------------------------------- Diagnosis page

class _DiagnosisPage extends StatelessWidget {
  const _DiagnosisPage();

  Color _sev(Severity s) => switch (s) {
        Severity.critical => AppColors.danger,
        Severity.warning => AppColors.warn,
        Severity.info => AppColors.info,
      };

  IconData _icon(Severity s) => switch (s) {
        Severity.critical => Icons.error,
        Severity.warning => Icons.warning_amber_rounded,
        Severity.info => Icons.info_outline,
      };

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<EcuService>();
    final r = svc.report;
    final ok = r.status == ReportStatus.healthy;

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Panel(
          child: Row(
            children: [
              Icon(
                ok ? Icons.check_circle : Icons.query_stats,
                color: ok ? AppColors.accent : AppColors.textDim,
                size: 32,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(r.message,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    Text('${r.samplesUsed} samples analysed',
                        style: const TextStyle(
                            color: AppColors.textDim, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        for (final f in r.findings) ...[
          _FindingCard(f: f, color: _sev(f.severity), icon: _icon(f.severity)),
          const SizedBox(height: 12),
        ],
        const SectionTitle('ECU stored codes'),
        Panel(
          child: svc.ecuDtcs.isEmpty
              ? const Text('No codes reported by the ECU.',
                  style: TextStyle(color: AppColors.textDim))
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (final c in svc.ecuDtcs)
                      Text('P${c.toRadixString(16).toUpperCase().padLeft(4, '0')}',
                          style: const TextStyle(
                              fontFamily: 'monospace', fontSize: 16)),
                    const SizedBox(height: 8),
                    OutlinedButton(
                        onPressed: svc.clearEcuDtcs,
                        child: const Text('Clear ECU codes')),
                  ],
                ),
        ),
      ],
    );
  }
}

class _FindingCard extends StatelessWidget {
  const _FindingCard(
      {required this.f, required this.color, required this.icon});
  final Finding f;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.6)),
      ),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color),
              const SizedBox(width: 8),
              Expanded(
                child: Text(f.title,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(f.component,
              style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
          const SizedBox(height: 10),
          Row(
            children: [
              const Text('Confidence',
                  style: TextStyle(color: AppColors.textDim, fontSize: 12)),
              const SizedBox(width: 8),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: f.confidence,
                    minHeight: 6,
                    backgroundColor: Colors.white10,
                    color: color,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text('${(f.confidence * 100).round()}%',
                  style: const TextStyle(fontSize: 12)),
            ],
          ),
          const SizedBox(height: 10),
          for (final e in f.evidence)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('•  '),
                  Expanded(child: Text(e, style: const TextStyle(fontSize: 13))),
                ],
              ),
            ),
          const SizedBox(height: 6),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(f.action, style: const TextStyle(fontSize: 13)),
          ),
        ],
      ),
    );
  }
}
