import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:usb_serial/usb_serial.dart';

import '../../comm/bluetooth_transport.dart';
import '../../comm/simulator_transport.dart';
import '../../comm/usb_transport.dart';
import '../../services/ecu_service.dart';
import '../theme.dart';
import '../widgets/panel.dart';

class ConnectScreen extends StatelessWidget {
  const ConnectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<EcuService>();
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Gas ECU Diagnostics'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.bluetooth), text: 'Bluetooth'),
              Tab(icon: Icon(Icons.usb), text: 'USB OTG'),
              Tab(icon: Icon(Icons.science_outlined), text: 'Simulator'),
            ],
          ),
        ),
        body: Column(
          children: [
            if (svc.state == LinkState.connecting)
              const LinearProgressIndicator(minHeight: 3),
            if (svc.error != null)
              Container(
                width: double.infinity,
                color: AppColors.danger.withValues(alpha: 0.15),
                padding: const EdgeInsets.all(12),
                child: Text('Connection failed: ${svc.error}',
                    style: const TextStyle(color: AppColors.danger)),
              ),
            const Expanded(
              child: TabBarView(
                children: [_BluetoothTab(), _UsbTab(), _SimulatorTab()],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BluetoothTab extends StatefulWidget {
  const _BluetoothTab();
  @override
  State<_BluetoothTab> createState() => _BluetoothTabState();
}

class _BluetoothTabState extends State<_BluetoothTab> {
  List<BluetoothDevice> _devices = [];
  String? _error;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final st = await [Permission.bluetoothConnect, Permission.bluetoothScan]
          .request();
      if (st[Permission.bluetoothConnect]?.isGranted != true) {
        throw 'Bluetooth permission denied';
      }
      final bt = FlutterBluetoothSerial.instance;
      if (await bt.isEnabled != true) await bt.requestEnable();
      _devices = await bt.getBondedDevices();
    } catch (e) {
      _error = '$e';
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const SectionTitle('Paired devices'),
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: Text(
            'Pair the adapter first in Android Bluetooth settings (PIN is '
            'usually 1234 or 0000), then pull to refresh.',
            style: TextStyle(color: AppColors.textDim, fontSize: 12),
          ),
        ),
        if (_loading) const Center(child: CircularProgressIndicator()),
        if (_error != null)
          Text(_error!, style: const TextStyle(color: AppColors.danger)),
        for (final d in _devices)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Panel(
              padding: EdgeInsets.zero,
              child: ListTile(
                leading: const Icon(Icons.bluetooth, color: AppColors.info),
                title: Text(d.name ?? 'Unknown'),
                subtitle: Text(d.address),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context
                    .read<EcuService>()
                    .connect(BluetoothTransport(d)),
              ),
            ),
          ),
        if (!_loading && _devices.isEmpty && _error == null)
          const Text('No paired devices found.'),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _load,
          icon: const Icon(Icons.refresh),
          label: const Text('Refresh'),
        ),
      ],
    );
  }
}

class _UsbTab extends StatefulWidget {
  const _UsbTab();
  @override
  State<_UsbTab> createState() => _UsbTabState();
}

class _UsbTabState extends State<_UsbTab> {
  List<UsbDevice> _devices = [];
  int _baud = 115200;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _load();
    UsbSerial.usbEventStream?.listen((_) => _load());
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await UsbSerial.listDevices();
    if (mounted) {
      setState(() {
        _devices = list;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const SectionTitle('Baud rate'),
        Panel(
          child: DropdownButton<int>(
            value: _baud,
            isExpanded: true,
            underline: const SizedBox.shrink(),
            items: const [9600, 19200, 38400, 57600, 115200]
                .map((b) => DropdownMenuItem(value: b, child: Text('$b')))
                .toList(),
            onChanged: (v) => setState(() => _baud = v ?? _baud),
          ),
        ),
        const SectionTitle('USB devices'),
        if (_loading) const Center(child: CircularProgressIndicator()),
        for (final d in _devices)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Panel(
              padding: EdgeInsets.zero,
              child: ListTile(
                leading: const Icon(Icons.usb, color: AppColors.accent),
                title: Text(d.productName ?? d.deviceName),
                subtitle: Text(
                    '${d.manufacturerName ?? '—'}  •  VID ${d.vid?.toRadixString(16)}  PID ${d.pid?.toRadixString(16)}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context
                    .read<EcuService>()
                    .connect(UsbTransport(d, baudRate: _baud)),
              ),
            ),
          ),
        if (!_loading && _devices.isEmpty)
          const Text('No USB serial device detected. Connect the OTG cable.'),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _load,
          icon: const Icon(Icons.refresh),
          label: const Text('Rescan'),
        ),
      ],
    );
  }
}

class _SimulatorTab extends StatefulWidget {
  const _SimulatorTab();
  @override
  State<_SimulatorTab> createState() => _SimulatorTabState();
}

class _SimulatorTabState extends State<_SimulatorTab> {
  SimFault _fault = SimFault.none;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const SectionTitle('Scenario'),
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: Text(
            'Simulates an ECU sending real framed bytes. Wait ~25 s so the '
            'engine sees a full idle → high-load sweep.',
            style: TextStyle(color: AppColors.textDim, fontSize: 12),
          ),
        ),
        for (final f in SimFault.values)
          RadioListTile<SimFault>(
            value: f,
            groupValue: _fault,
            onChanged: (v) => setState(() => _fault = v ?? _fault),
            title: Text(f.label),
            activeColor: AppColors.accent,
          ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () =>
              context.read<EcuService>().connect(SimulatorTransport(fault: _fault)),
          icon: const Icon(Icons.play_arrow),
          label: const Text('Start simulation'),
        ),
      ],
    );
  }
}
