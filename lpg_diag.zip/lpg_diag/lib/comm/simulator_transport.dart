import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import '../core/models/telemetry.dart';
import '../protocol/ecu_protocol.dart';
import 'ecu_transport.dart';

enum SimFault {
  none('Healthy system'),
  cloggedFilter('Clogged gas filter'),
  faultyReducer('Faulty reducer (unstable pressure)'),
  coldReducer('Reducer not heating'),
  restrictedInjector2('Restricted injector #2'),
  gasSensorOpen('Gas MAP sensor open circuit');

  const SimFault(this.label);
  final String label;
}

/// Pure physical-ish model of a running LPG system. Used by the simulator
/// transport and by unit tests (no timers, fully deterministic given [seed]).
class EcuSimModel {
  EcuSimModel({this.fault = SimFault.none, this.injectors = 4, int seed = 7})
      : _rnd = math.Random(seed);

  SimFault fault;
  final int injectors;
  final math.Random _rnd;

  double _noise(double amp) => (_rnd.nextDouble() * 2 - 1) * amp;

  /// [t] = seconds since start. Engine load sweeps idle -> high -> idle every
  /// 24 s so the diagnostic engine sees both load regimes.
  Telemetry sample(double t) {
    final load = 0.5 + 0.5 * math.sin(2 * math.pi * t / 24 - math.pi / 2);
    final rpm = 850 + 2400 * load + _noise(15);
    final manifold = 32 + 58 * load + _noise(0.4);
    final injMs = 2.2 + 7.0 * load;

    var delta = 100 - 6 * load + _noise(0.6);
    var temp = 40 + math.min(t * 0.8, 38.0);

    switch (fault) {
      case SimFault.cloggedFilter:
        delta -= 75 * math.pow(load, 1.2);
        break;
      case SimFault.faultyReducer:
        delta += 30 * math.sin(2 * math.pi * t / 1.3) + _noise(8);
        break;
      case SimFault.coldReducer:
        temp = 22 + _noise(0.3);
        delta -= 30 * load;
        break;
      default:
        break;
    }

    var gasMap = manifold + delta;
    if (fault == SimFault.gasSensorOpen) gasMap = 0;

    final inj = <double>[
      for (var i = 0; i < injectors; i++)
        injMs * (1 + _noise(0.02)) *
            (fault == SimFault.restrictedInjector2 && i == 1 ? 1.3 : 1.0)
    ];

    return Telemetry(
      timestamp: DateTime.now(),
      gasMapKpa: gasMap,
      manifoldMapKpa: manifold,
      reducerTempC: temp,
      rpm: rpm.round(),
      gasInjectorMs: inj,
      petrolInjectorMs: 0,
      batteryV: 13.8 + _noise(0.1),
      mode: FuelMode.gas,
    );
  }

  List<int> get dtcs => switch (fault) {
        SimFault.gasSensorOpen => [0x0115],
        SimFault.coldReducer => [0x0116],
        _ => const [],
      };
}

/// Emits real framed bytes (through the same encoder the parser decodes), in
/// deliberately awkward chunk sizes, so the full RX path is exercised.
class SimulatorTransport implements EcuTransport {
  SimulatorTransport({SimFault fault = SimFault.none, int injectors = 4})
      : model = EcuSimModel(fault: fault, injectors: injectors);

  final EcuSimModel model;
  final StreamController<Uint8List> _in = StreamController<Uint8List>.broadcast();
  Timer? _timer;
  double _t = 0;
  bool _connected = false;

  @override
  String get name => 'Simulator – ${model.fault.label}';

  @override
  bool get isConnected => _connected;

  @override
  Stream<Uint8List> get input => _in.stream;

  @override
  Future<void> connect() async {
    _connected = true;
    _timer = Timer.periodic(const Duration(milliseconds: 100), (_) {
      _t += 0.1;
      _emit(encodeTelemetry(model.sample(_t)));
    });
    Timer(const Duration(seconds: 1), () => _emit(encodeDtcList(model.dtcs)));
  }

  void _emit(Uint8List frame) {
    if (_in.isClosed) return;
    // Split into two chunks to mimic fragmented serial reads.
    final cut = frame.length ~/ 2;
    _in.add(Uint8List.sublistView(frame, 0, cut));
    _in.add(Uint8List.sublistView(frame, cut));
  }

  @override
  Future<void> write(Uint8List data) async {
    // Respond to DTC reads; stream start/stop are ignored by the simulator.
  }

  @override
  Future<void> disconnect() async {
    _timer?.cancel();
    _connected = false;
    if (!_in.isClosed) await _in.close();
  }
}
