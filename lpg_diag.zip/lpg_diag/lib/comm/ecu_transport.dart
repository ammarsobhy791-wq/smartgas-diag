import 'dart:typed_data';

/// Byte-pipe abstraction so Bluetooth, USB OTG and the simulator are
/// interchangeable. A transport instance is single-use.
abstract class EcuTransport {
  String get name;
  bool get isConnected;

  /// Raw bytes received from the ECU (chunks of arbitrary size).
  Stream<Uint8List> get input;

  Future<void> connect();
  Future<void> write(Uint8List data);
  Future<void> disconnect();
}
