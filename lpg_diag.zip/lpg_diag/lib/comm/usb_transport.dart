import 'dart:async';
import 'dart:typed_data';

import 'package:usb_serial/usb_serial.dart';

import 'ecu_transport.dart';

/// USB OTG serial transport (CDC-ACM, FTDI, CH34x, CP210x, PL2303).
class UsbTransport implements EcuTransport {
  UsbTransport(this.device, {this.baudRate = 115200});

  final UsbDevice device;
  final int baudRate;
  UsbPort? _port;
  StreamSubscription<Uint8List>? _sub;
  final StreamController<Uint8List> _in = StreamController<Uint8List>.broadcast();

  @override
  String get name => device.productName ?? device.deviceName;

  @override
  bool get isConnected => _port != null;

  @override
  Stream<Uint8List> get input => _in.stream;

  @override
  Future<void> connect() async {
    final port = await device.create();
    if (port == null) throw StateError('USB device not supported');
    if (!await port.open()) {
      throw StateError('Could not open USB port (permission denied?)');
    }
    await port.setDTR(true);
    await port.setRTS(true);
    await port.setPortParameters(
      baudRate,
      UsbPort.DATABITS_8,
      UsbPort.STOPBITS_1,
      UsbPort.PARITY_NONE,
    );
    _port = port;
    _sub = port.inputStream!.listen(
      _in.add,
      onError: _in.addError,
      onDone: () {
        if (!_in.isClosed) _in.close();
      },
    );
  }

  @override
  Future<void> write(Uint8List data) async {
    final p = _port;
    if (p == null) throw StateError('USB not connected');
    await p.write(data);
  }

  @override
  Future<void> disconnect() async {
    await _sub?.cancel();
    _sub = null;
    try {
      await _port?.close();
    } catch (_) {}
    _port = null;
    if (!_in.isClosed) await _in.close();
  }
}
