import 'dart:async';
import 'dart:typed_data';

import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';

import 'ecu_transport.dart';

/// Bluetooth Classic (SPP/RFCOMM) transport. The adapter must be paired in
/// Android settings first.
class BluetoothTransport implements EcuTransport {
  BluetoothTransport(this.device);

  final BluetoothDevice device;
  BluetoothConnection? _conn;
  StreamSubscription<Uint8List>? _sub;
  final StreamController<Uint8List> _in = StreamController<Uint8List>.broadcast();

  @override
  String get name => device.name ?? device.address;

  @override
  bool get isConnected => _conn?.isConnected ?? false;

  @override
  Stream<Uint8List> get input => _in.stream;

  @override
  Future<void> connect() async {
    final conn = await BluetoothConnection.toAddress(device.address);
    _conn = conn;
    _sub = conn.input!.listen(
      _in.add,
      onError: _in.addError,
      onDone: () {
        if (!_in.isClosed) _in.close();
      },
    );
  }

  @override
  Future<void> write(Uint8List data) async {
    final c = _conn;
    if (c == null || !c.isConnected) throw StateError('Bluetooth not connected');
    c.output.add(data);
    await c.output.allSent;
  }

  @override
  Future<void> disconnect() async {
    await _sub?.cancel();
    _sub = null;
    try {
      await _conn?.close();
    } catch (_) {}
    _conn = null;
    if (!_in.isClosed) await _in.close();
  }
}
