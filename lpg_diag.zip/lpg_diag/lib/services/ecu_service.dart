import 'dart:async';
import 'dart:collection';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../comm/ecu_transport.dart';
import '../core/models/finding.dart';
import '../core/models/telemetry.dart';
import '../diagnostics/fault_engine.dart';
import '../protocol/ecu_protocol.dart';

enum LinkState { disconnected, connecting, connected, error }

/// Owns the transport, decodes the byte stream, keeps history and runs the
/// fault engine. The UI only listens to this object.
class EcuService extends ChangeNotifier {
  EcuService({FaultEngine? engine}) : _engine = engine ?? FaultEngine();

  static const int maxHistory = 600; // 60 s at 10 Hz

  final FaultEngine _engine;
  final FrameParser _parser = FrameParser();
  final List<Telemetry> _history = <Telemetry>[];

  EcuTransport? _transport;
  StreamSubscription<Uint8List>? _sub;
  Timer? _tick;
  int _tickCount = 0;

  LinkState state = LinkState.disconnected;
  String? error;
  String? deviceName;
  Telemetry? latest;
  DateTime? lastFrameAt;
  int framesOk = 0;
  List<int> ecuDtcs = const [];
  DiagnosticReport report = DiagnosticReport.empty();

  UnmodifiableListView<Telemetry> get history => UnmodifiableListView(_history);
  int get crcErrors => _parser.crcErrors;

  bool get isStale =>
      state == LinkState.connected &&
      (lastFrameAt == null ||
          DateTime.now().difference(lastFrameAt!) > const Duration(seconds: 3));

  Future<void> connect(EcuTransport transport) async {
    await disconnect();
    _transport = transport;
    deviceName = transport.name;
    state = LinkState.connecting;
    error = null;
    notifyListeners();
    try {
      await transport.connect();
      _sub = transport.input.listen(
        _onBytes,
        onError: (Object e) => _fail('$e'),
        onDone: () {
          if (state == LinkState.connected) _fail('Connection closed by device');
        },
      );
      state = LinkState.connected;
      _tick = Timer.periodic(const Duration(seconds: 1), (_) {
        _tickCount++;
        if (_tickCount % 2 == 0) _analyze();
        notifyListeners(); // refreshes stale indicator
      });
      notifyListeners();
      await transport.write(buildFrame(Cmd.startStream, [100])); // 100 ms
      await transport.write(buildFrame(Cmd.readDtc));
    } catch (e) {
      _fail(e.toString());
    }
  }

  Future<void> disconnect() async {
    _tick?.cancel();
    _tick = null;
    await _sub?.cancel();
    _sub = null;
    final t = _transport;
    _transport = null;
    if (t != null) {
      try {
        await t.write(buildFrame(Cmd.stopStream));
      } catch (_) {}
      await t.disconnect();
    }
    if (state != LinkState.error) state = LinkState.disconnected;
    notifyListeners();
  }

  Future<void> clearEcuDtcs() async {
    await _transport?.write(buildFrame(Cmd.clearDtc));
    ecuDtcs = const [];
    notifyListeners();
  }

  void clearHistory() {
    _history.clear();
    report = DiagnosticReport.empty();
    notifyListeners();
  }

  void _onBytes(Uint8List data) {
    var changed = false;
    for (final fr in _parser.feed(data)) {
      switch (fr.cmd) {
        case Cmd.telemetry:
          final t = decodeTelemetry(fr.payload);
          if (t == null) continue;
          latest = t;
          lastFrameAt = DateTime.now();
          framesOk++;
          _history.add(t);
          if (_history.length > maxHistory) {
            _history.removeRange(0, _history.length - maxHistory);
          }
          changed = true;
          break;
        case Cmd.dtcList:
          ecuDtcs = decodeDtcList(fr.payload);
          changed = true;
          break;
      }
    }
    if (changed) notifyListeners();
  }

  void _analyze() {
    report = _engine.analyze(_history);
  }

  Future<void> _fail(String message) async {
    error = message;
    state = LinkState.error;
    await disconnect();
    state = LinkState.error;
    notifyListeners();
  }

  @override
  void dispose() {
    _tick?.cancel();
    _sub?.cancel();
    _transport?.disconnect();
    super.dispose();
  }
}
