enum FuelMode { petrol, gas, switching, unknown }

/// One decoded live-data sample from the gas ECU.
class Telemetry {
  const Telemetry({
    required this.timestamp,
    required this.gasMapKpa,
    required this.manifoldMapKpa,
    required this.reducerTempC,
    required this.rpm,
    required this.gasInjectorMs,
    required this.petrolInjectorMs,
    required this.batteryV,
    required this.mode,
  });

  final DateTime timestamp;

  /// Absolute pressure in the gas rail (after reducer), kPa.
  final double gasMapKpa;

  /// Intake manifold absolute pressure, kPa.
  final double manifoldMapKpa;
  final double reducerTempC;
  final int rpm;

  /// Opening time of each gas injector, ms.
  final List<double> gasInjectorMs;
  final double petrolInjectorMs;
  final double batteryV;
  final FuelMode mode;

  /// Gas rail overpressure relative to the manifold. This is the value the
  /// reducer actually regulates (typically ~80-120 kPa for LPG).
  double get pressureDeltaKpa => gasMapKpa - manifoldMapKpa;

  double get avgGasInjectorMs => gasInjectorMs.isEmpty
      ? 0
      : gasInjectorMs.reduce((a, b) => a + b) / gasInjectorMs.length;

  /// Injector duty cycle in %, 4-stroke (one injection per 2 revolutions):
  /// duty = t_ms * rpm / 1200.
  double get dutyPercent => avgGasInjectorMs * rpm / 1200.0;
}
