enum Severity { info, warning, critical }

/// A single diagnostic conclusion produced by the fault engine.
class Finding {
  const Finding({
    required this.id,
    required this.title,
    required this.component,
    required this.severity,
    required this.confidence,
    required this.evidence,
    required this.action,
    this.injectorIndex,
  });

  final String id;
  final String title;
  final String component;
  final Severity severity;

  /// 0..1, how strongly the evidence supports this conclusion.
  final double confidence;
  final List<String> evidence;
  final String action;

  /// 0-based injector index when the finding isolates one injector.
  final int? injectorIndex;
}

enum ReportStatus { insufficientData, healthy, faultsFound }

class DiagnosticReport {
  const DiagnosticReport({
    required this.status,
    required this.findings,
    required this.samplesUsed,
    required this.message,
  });

  factory DiagnosticReport.empty() => const DiagnosticReport(
        status: ReportStatus.insufficientData,
        findings: [],
        samplesUsed: 0,
        message: 'Waiting for data. Run the engine on gas.',
      );

  final ReportStatus status;
  final List<Finding> findings;
  final int samplesUsed;
  final String message;

  Set<int> get flaggedInjectors => {
        for (final f in findings)
          if (f.injectorIndex != null && f.severity != Severity.info)
            f.injectorIndex!
      };
}
