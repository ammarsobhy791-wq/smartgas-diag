import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'services/ecu_service.dart';
import 'ui/screens/connect_screen.dart';
import 'ui/screens/dashboard_screen.dart';
import 'ui/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => EcuService(),
      child: const GasDiagApp(),
    ),
  );
}

class GasDiagApp extends StatelessWidget {
  const GasDiagApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gas ECU Diagnostics',
      debugShowCheckedModeBanner: false,
      theme: buildDarkTheme(),
      home: Consumer<EcuService>(
        builder: (_, svc, __) => svc.state == LinkState.connected
            ? const DashboardScreen()
            : const ConnectScreen(),
      ),
    );
  }
}
