import 'dart:math' as math;

class Stats {
  static double mean(Iterable<double> v) {
    if (v.isEmpty) return 0;
    return v.reduce((a, b) => a + b) / v.length;
  }

  static double std(List<double> v) {
    if (v.length < 2) return 0;
    final m = mean(v);
    var s = 0.0;
    for (final x in v) {
      s += (x - m) * (x - m);
    }
    return math.sqrt(s / (v.length - 1));
  }

  static double median(List<double> v) {
    final s = [...v]..sort();
    final n = s.length;
    if (n == 0) return 0;
    return n.isOdd ? s[n ~/ 2] : (s[n ~/ 2 - 1] + s[n ~/ 2]) / 2;
  }

  /// Least squares y = slope*x + intercept, plus std of the residuals.
  /// Returns null when x has no spread.
  static ({double slope, double intercept, double residualStd})? linreg(
      List<double> x, List<double> y) {
    final n = x.length;
    if (n < 3 || y.length != n) return null;
    final mx = mean(x), my = mean(y);
    var sxx = 0.0, sxy = 0.0;
    for (var i = 0; i < n; i++) {
      sxx += (x[i] - mx) * (x[i] - mx);
      sxy += (x[i] - mx) * (y[i] - my);
    }
    if (sxx < 1e-9) return null;
    final slope = sxy / sxx;
    final intercept = my - slope * mx;
    final res = [for (var i = 0; i < n; i++) y[i] - (slope * x[i] + intercept)];
    return (slope: slope, intercept: intercept, residualStd: std(res));
  }
}
