import '../core/models/finding.dart';
import '../core/models/telemetry.dart';
import 'stats.dart';

/// Tunable limits. Defaults suit a typical sequential LPG system with the gas
/// rail ~100 kPa above manifold pressure. Calibrate per ECU / reducer type.
class FaultThresholds {
  const FaultThresholds({
    this.minSamples = 40,
    this.minBucketSamples = 8,
    this.nominalDeltaMinKpa = 60,
    this.nominalDeltaMaxKpa = 140,
    this.lowLoadDutyMax = 6,
    this.highLoadDutyMin = 15,
    this.filterDropRatio = 0.18,
    this.reducerResidualStdKpa = 12,
    this.reducerTempMinC = 35,
    this.reducerTempMaxC = 95,
    this.injectorDeviation = 0.12,
    this.sensorMinKpa = 5,
    this.sensorMaxKpa = 480,
    this.batteryMinV = 11.8,
    this.batteryMaxV = 15.2,
  });

  final int minSamples;
  final int minBucketSamples;
  final double nominalDeltaMinKpa;
  final double nominalDeltaMaxKpa;
  final double lowLoadDutyMax;
  final double highLoadDutyMin;
  final double filterDropRatio;
  final double reducerResidualStdKpa;
  final double reducerTempMinC;
  final double reducerTempMaxC;
  final double injectorDeviation;
  final double sensorMinKpa;
  final double sensorMaxKpa;
  final double batteryMinV;
  final double batteryMaxV;
}

/// Rule-based fault localisation over a sliding window of telemetry.
///
/// The key idea is to separate *where* a symptom comes from by how it behaves:
///   * Load-dependent pressure drop, smooth, reducer warm   -> gas filter
///   * Pressure wrong / unstable independent of load        -> reducer
///   * One injector deviates from its siblings (common-mode removed) -> injector
///   * Sensor railed / frozen                               -> sensor wiring
class FaultEngine {
  FaultEngine({this.th = const FaultThresholds()});

  final FaultThresholds th;

  DiagnosticReport analyze(List<Telemetry> window) {
    final gas = window
        .where((t) => t.mode == FuelMode.gas && t.rpm >= 500)
        .toList(growable: false);

    if (gas.length < th.minSamples) {
      return DiagnosticReport(
        status: ReportStatus.insufficientData,
        findings: const [],
        samplesUsed: gas.length,
        message:
            'Need ${th.minSamples} samples on gas with engine running '
            '(have ${gas.length}).',
      );
    }

    final f = <Finding>[];
    _battery(window, f);
    final sensorBad = _gasSensor(gas, f);
    if (!sensorBad) _pressure(gas, f);
    _injectors(gas, f);

    f.sort((a, b) {
      final s = b.severity.index.compareTo(a.severity.index);
      return s != 0 ? s : b.confidence.compareTo(a.confidence);
    });

    final real = f.where((x) => x.severity != Severity.info).isNotEmpty;
    return DiagnosticReport(
      status: real ? ReportStatus.faultsFound : ReportStatus.healthy,
      findings: f,
      samplesUsed: gas.length,
      message: real
          ? '${f.where((x) => x.severity != Severity.info).length} issue(s) located'
          : 'No faults detected in the current window.',
    );
  }

  // ---- helpers ------------------------------------------------------------

  double _clamp(double v, [double lo = 0.0, double hi = 0.97]) =>
      v.clamp(lo, hi).toDouble();

  String _f(double v, [int d = 0]) => v.toStringAsFixed(d);

  // ---- rules --------------------------------------------------------------

  void _battery(List<Telemetry> w, List<Finding> out) {
    final v = Stats.mean(w.map((t) => t.batteryV));
    if (v <= 0.1) return;
    if (v < th.batteryMinV || v > th.batteryMaxV) {
      out.add(Finding(
        id: 'supply_voltage',
        title: v < th.batteryMinV ? 'Low supply voltage' : 'High supply voltage',
        component: 'Electrical',
        severity: Severity.warning,
        confidence: 0.8,
        evidence: ['Mean ECU supply ${_f(v, 1)} V (limits '
            '${_f(th.batteryMinV, 1)}–${_f(th.batteryMaxV, 1)} V)'],
        action: 'Check battery, alternator output and the ECU supply/ground '
            'connections before trusting other readings.',
      ));
    }
  }

  /// Returns true if the gas pressure sensor is judged unusable.
  bool _gasSensor(List<Telemetry> g, List<Finding> out) {
    final bad = g
        .where((t) =>
            t.gasMapKpa < th.sensorMinKpa || t.gasMapKpa > th.sensorMaxKpa)
        .length;
    final frac = bad / g.length;
    if (frac > 0.8) {
      final high = Stats.mean(g.map((t) => t.gasMapKpa)) > th.sensorMaxKpa;
      out.add(Finding(
        id: 'gas_map_sensor',
        title: high
            ? 'Gas pressure sensor shorted high'
            : 'Gas pressure sensor open / shorted low',
        component: 'Gas MAP sensor',
        severity: Severity.critical,
        confidence: 0.92,
        evidence: [
          '${_f(frac * 100)}% of samples outside '
              '${_f(th.sensorMinKpa)}–${_f(th.sensorMaxKpa)} kPa',
          'Reading is railed, so pressure-based rules (filter / reducer) were '
              'suppressed.',
        ],
        action: 'Check the sensor connector and 5 V / ground / signal wiring, '
            'then re-run the test. Replace the sensor if wiring is good.',
      ));
      return true;
    }

    // Frozen sensor: no variation although load clearly changes.
    final p = g.map((t) => t.gasMapKpa).toList();
    final duty = g.map((t) => t.dutyPercent).toList();
    if (Stats.std(p) < 0.05 && Stats.std(duty) > 3) {
      out.add(Finding(
        id: 'gas_map_stuck',
        title: 'Gas pressure sensor reading frozen',
        component: 'Gas MAP sensor',
        severity: Severity.critical,
        confidence: 0.85,
        evidence: [
          'Gas MAP constant at ${_f(p.last, 1)} kPa while injector duty '
              'varied (σ ${_f(Stats.std(duty), 1)} %)',
        ],
        action: 'Replace or re-wire the sensor; check for a failed ADC channel.',
      ));
      return true;
    }
    return false;
  }

  void _pressure(List<Telemetry> g, List<Finding> out) {
    final dp = g.map((t) => t.pressureDeltaKpa).toList();
    final duty = g.map((t) => t.dutyPercent).toList();
    final temp = Stats.mean(g.map((t) => t.reducerTempC));

    List<double> bucket(bool Function(double d) pick) => [
          for (var i = 0; i < g.length; i++)
            if (pick(duty[i])) dp[i]
        ];
    final lowB = bucket((d) => d <= th.lowLoadDutyMax);
    final highB = bucket((d) => d >= th.highLoadDutyMin);
    final haveLow = lowB.length >= th.minBucketSamples;
    final haveHigh = highB.length >= th.minBucketSamples;

    final lowDp = haveLow ? Stats.mean(lowB) : null;
    final highDp = haveHigh ? Stats.mean(highB) : null;
    final drop = (lowDp != null && highDp != null && lowDp > 1)
        ? (lowDp - highDp) / lowDp
        : null;

    // Residual after removing the load-dependent trend: this is pure
    // "instability" that load cannot explain.
    final reg = Stats.linreg(duty, dp);
    final residual = reg?.residualStd ?? Stats.std(dp);

    final tempOk = temp >= th.reducerTempMinC && temp <= th.reducerTempMaxC;
    final stable = residual < th.reducerResidualStdKpa * 1.5;

    // 0. Nothing to evaluate without a load sweep.
    if (!haveLow || !haveHigh) {
      out.add(Finding(
        id: 'need_load_sweep',
        title: 'Load test incomplete',
        component: 'Procedure',
        severity: Severity.info,
        confidence: 1,
        evidence: [
          'Idle samples: ${lowB.length}, high-load samples: ${highB.length} '
              '(need ${th.minBucketSamples} each)',
        ],
        action: 'Hold idle for ~10 s, then raise to ~3000 rpm for ~10 s. This '
            'separates a clogged filter from a bad reducer.',
      ));
    }

    // 1. No gas flow at all.
    if (lowDp != null && lowDp < 10) {
      out.add(Finding(
        id: 'no_gas_flow',
        title: 'No gas pressure above manifold',
        component: 'Gas supply',
        severity: Severity.critical,
        confidence: 0.85,
        evidence: [
          'Idle ΔP ${_f(lowDp, 1)} kPa (expected ≥ ${_f(th.nominalDeltaMinKpa)})',
        ],
        action: 'Check tank contents, multivalve/service valve, gas solenoid '
            'operation and the main gas hose, then the filter.',
      ));
      return;
    }

    // 2. Clogged filter: pressure healthy at idle, collapses smoothly with
    //    flow demand, reducer warm.
    var cloggedFired = false;
    if (drop != null &&
        lowDp != null &&
        highDp != null &&
        drop >= th.filterDropRatio &&
        lowDp >= th.nominalDeltaMinKpa * 0.7 &&
        lowDp <= th.nominalDeltaMaxKpa &&
        stable &&
        tempOk) {
      cloggedFired = true;
      final conf = _clamp(0.55 + (drop - th.filterDropRatio) * 1.5);
      out.add(Finding(
        id: 'filter_clogged',
        title: 'Gas filter likely clogged',
        component: 'Gas filter',
        severity: highDp < th.nominalDeltaMinKpa * 0.5
            ? Severity.critical
            : Severity.warning,
        confidence: conf,
        evidence: [
          'Idle ΔP ${_f(lowDp, 1)} kPa → high load ${_f(highDp, 1)} kPa '
              '(−${_f(drop * 100)} %)',
          'Pressure is smooth (residual σ ${_f(residual, 1)} kPa): a restriction, '
              'not regulator hunting',
          'Reducer temperature normal (${_f(temp)} °C), so freezing is unlikely',
        ],
        action: 'Replace the liquid-phase and vapour-phase filter elements, '
            'then repeat the load sweep. If ΔP still collapses, inspect the '
            'gas hose and solenoid.',
      ));
    }

    // 3. Reducer faults.
    if (residual >= th.reducerResidualStdKpa) {
      final conf = _clamp(0.6 + (residual / th.reducerResidualStdKpa - 1) * 0.2);
      out.add(Finding(
        id: 'reducer_unstable',
        title: 'Reducer pressure unstable',
        component: 'Reducer',
        severity: Severity.warning,
        confidence: conf,
        evidence: [
          'Pressure scatter σ ${_f(residual, 1)} kPa after removing load trend '
              '(limit ${_f(th.reducerResidualStdKpa)})',
          if (drop != null) 'Load-related drop only ${_f(drop * 100)} %',
        ],
        action: 'Inspect reducer diaphragm and valve seat; confirm coolant '
            'flow and hose condition. Rebuild or replace the reducer.',
      ));
    } else if (lowDp != null && lowDp > th.nominalDeltaMaxKpa) {
      out.add(Finding(
        id: 'reducer_overpressure',
        title: 'Reducer over-pressure',
        component: 'Reducer',
        severity: Severity.warning,
        confidence: 0.75,
        evidence: [
          'Idle ΔP ${_f(lowDp, 1)} kPa (max ${_f(th.nominalDeltaMaxKpa)})',
        ],
        action: 'Valve seat leaking or pressure setpoint too high: check/adjust '
            'the reducer, replace the seat kit. Risk of rich running and '
            'injector leakage.',
      ));
    } else if (lowDp != null && lowDp < th.nominalDeltaMinKpa && !cloggedFired) {
      final flat = drop == null || drop < th.filterDropRatio;
      out.add(Finding(
        id: 'reducer_underpressure',
        title: flat
            ? 'Reducer under-pressure (not load-related)'
            : 'Low pressure with load dependence',
        component: flat ? 'Reducer' : 'Reducer / gas filter',
        severity: Severity.warning,
        confidence: flat ? 0.7 : 0.5,
        evidence: [
          'Idle ΔP ${_f(lowDp, 1)} kPa (min ${_f(th.nominalDeltaMinKpa)})',
          if (drop != null)
            flat
                ? 'Pressure is low regardless of load → regulator setpoint / '
                    'diaphragm, not a flow restriction'
                : 'Pressure also falls with load (−${_f(drop * 100)} %): '
                    'filter may be contributing',
        ],
        action: flat
            ? 'Check reducer setpoint and diaphragm; verify tank level.'
            : 'Replace filters first, then re-test; if still low, service the reducer.',
      ));
    }

    // 4. Reducer temperature (heating circuit).
    if (temp < th.reducerTempMinC) {
      out.add(Finding(
        id: 'reducer_cold',
        title: 'Reducer too cold while on gas',
        component: 'Reducer heating',
        severity: Severity.warning,
        confidence: 0.8,
        evidence: [
          'Mean reducer temperature ${_f(temp)} °C (min ${_f(th.reducerTempMinC)})',
          if (drop != null && drop >= th.filterDropRatio)
            'Load-related pressure drop (−${_f(drop * 100)} %) is consistent '
                'with reducer icing; filter rule was held back',
        ],
        action: 'Check coolant hoses/flow through the reducer, air in the '
            'cooling circuit, and the temperature sensor.',
      ));
    } else if (temp > th.reducerTempMaxC) {
      out.add(Finding(
        id: 'reducer_hot',
        title: 'Reducer overheating',
        component: 'Reducer heating',
        severity: Severity.warning,
        confidence: 0.7,
        evidence: ['Mean reducer temperature ${_f(temp)} °C'],
        action: 'Check engine cooling system and the reducer temperature sensor.',
      ));
    }
  }

  void _injectors(List<Telemetry> g, List<Finding> out) {
    final n = g.first.gasInjectorMs.length;
    if (n < 3) return; // need ≥3 to tell which one deviates

    final valid = g
        .where((t) =>
            t.gasInjectorMs.length == n && Stats.median(t.gasInjectorMs) > 1.0)
        .toList();
    if (valid.length < th.minSamples) return;

    for (var i = 0; i < n; i++) {
      // Ratio to the per-sample median removes anything common to all
      // injectors (pressure, load, global trim), leaving only this injector.
      final ratios = [
        for (final t in valid) t.gasInjectorMs[i] / Stats.median(t.gasInjectorMs)
      ];
      final meanR = Stats.mean(ratios);
      final dir = meanR >= 1 ? 1 : -1;
      final consistent = ratios
              .where((r) => (r - 1) * dir > th.injectorDeviation * 0.5)
              .length /
          ratios.length;

      if (meanR < 0.15) {
        out.add(Finding(
          id: 'injector_dead_$i',
          title: 'Injector ${i + 1} not firing',
          component: 'Injector ${i + 1}',
          severity: Severity.critical,
          confidence: 0.9,
          evidence: [
            'Injector ${i + 1} at ${_f(meanR * 100)} % of siblings’ opening time',
          ],
          action: 'Check injector connector/wiring and coil resistance '
              '(typically 1–3 Ω); swap with a neighbour to confirm.',
          injectorIndex: i,
        ));
      } else if ((meanR - 1).abs() >= th.injectorDeviation && consistent >= 0.8) {
        final high = meanR > 1;
        out.add(Finding(
          id: 'injector_dev_$i',
          title: high
              ? 'Injector ${i + 1} restricted / cylinder lean'
              : 'Injector ${i + 1} over-delivering / cylinder rich',
          component: 'Injector ${i + 1}',
          severity: Severity.warning,
          confidence: _clamp(0.55 + ((meanR - 1).abs() - th.injectorDeviation) * 2),
          evidence: [
            'Opening time ${high ? '+' : ''}${_f((meanR - 1) * 100)} % vs '
                'sibling median (${_f(consistent * 100)} % of samples agree)',
            'Other injectors are consistent, so the supply side '
                '(filter/reducer) is not the cause',
          ],
          action: high
              ? 'ECU is adding gas to this cylinder: clean/replace the injector '
                  'nozzle, check its hose for kinks and the cylinder for a '
                  'vacuum leak or low compression.'
              : 'ECU is trimming this cylinder: check for a leaking injector or '
                  'a petrol-side fault on this cylinder.',
          injectorIndex: i,
        ));
      }
    }
  }
}
