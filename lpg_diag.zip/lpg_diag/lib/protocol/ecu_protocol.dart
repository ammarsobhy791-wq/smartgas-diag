import 'dart:typed_data';

import '../core/models/telemetry.dart';

/// Command IDs of the (configurable) framed serial protocol.
///
/// Frame: AA 55 | LEN | CMD | PAYLOAD[LEN] | CRC8(LEN,CMD,PAYLOAD)
///
/// IMPORTANT: real LPG/CNG ECUs (STAG, BRC, Zenit, Landi Renzo, KME...) use
/// proprietary protocols. This file is the ONLY place that knows the wire
/// format: adapt [Cmd], [decodeTelemetry] and [buildFrame] to your ECU.
class Cmd {
  static const int telemetry = 0x01;
  static const int dtcList = 0x02;
  static const int startStream = 0x10;
  static const int stopStream = 0x11;
  static const int readDtc = 0x12;
  static const int clearDtc = 0x13;
}

/// CRC-8 (poly 0x07, init 0x00).
int crc8(List<int> data, {int poly = 0x07, int init = 0}) {
  var crc = init;
  for (final b in data) {
    crc ^= b & 0xFF;
    for (var i = 0; i < 8; i++) {
      crc = (crc & 0x80) != 0 ? ((crc << 1) ^ poly) & 0xFF : (crc << 1) & 0xFF;
    }
  }
  return crc;
}

Uint8List buildFrame(int cmd, [List<int> payload = const []]) {
  final body = <int>[payload.length, cmd, ...payload];
  return Uint8List.fromList([0xAA, 0x55, ...body, crc8(body)]);
}

class EcuFrame {
  const EcuFrame(this.cmd, this.payload);
  final int cmd;
  final Uint8List payload;
}

/// Incremental, resynchronising frame parser. Feed it raw serial chunks of any
/// size; it returns complete, CRC-valid frames.
class FrameParser {
  static const int maxPayload = 64;
  static const int _maxBuffer = 2048;

  final List<int> _buf = <int>[];
  int crcErrors = 0;

  List<EcuFrame> feed(List<int> data) {
    _buf.addAll(data);
    if (_buf.length > _maxBuffer) _buf.clear();
    final out = <EcuFrame>[];

    while (true) {
      var i = 0;
      while (i + 1 < _buf.length && !(_buf[i] == 0xAA && _buf[i + 1] == 0x55)) {
        i++;
      }
      if (i > 0) _buf.removeRange(0, i);
      if (_buf.length < 5) break;

      final len = _buf[2];
      if (len > maxPayload) {
        _buf.removeAt(0);
        continue;
      }
      final total = len + 5;
      if (_buf.length < total) break;

      final body = _buf.sublist(2, total - 1);
      if (crc8(body) == _buf[total - 1]) {
        out.add(EcuFrame(
            body[1], Uint8List.fromList(body.sublist(2))));
        _buf.removeRange(0, total);
      } else {
        crcErrors++;
        _buf.removeAt(0); // resync on next header
      }
    }
    return out;
  }
}

// ---------------------------------------------------------------------------
// Telemetry payload (little endian)
//  0  u16 gas MAP            0.1 kPa
//  2  u16 manifold MAP       0.1 kPa
//  4  i16 reducer temp       0.1 °C
//  6  u16 rpm
//  8  u8  mode (0 petrol, 1 gas, 2 switching)
//  9  u16 petrol inj time    0.01 ms
// 11  u16 battery            mV
// 13  u8  N injectors
// 14  N x u16 gas inj time   0.01 ms
// ---------------------------------------------------------------------------

Telemetry? decodeTelemetry(Uint8List p, {DateTime? now}) {
  if (p.length < 14) return null;
  final n = p[13];
  if (n < 1 || n > 8 || p.length < 14 + 2 * n) return null;
  final b = ByteData.sublistView(p);
  final mode = switch (p[8]) {
    0 => FuelMode.petrol,
    1 => FuelMode.gas,
    2 => FuelMode.switching,
    _ => FuelMode.unknown,
  };
  return Telemetry(
    timestamp: now ?? DateTime.now(),
    gasMapKpa: b.getUint16(0, Endian.little) / 10.0,
    manifoldMapKpa: b.getUint16(2, Endian.little) / 10.0,
    reducerTempC: b.getInt16(4, Endian.little) / 10.0,
    rpm: b.getUint16(6, Endian.little),
    mode: mode,
    petrolInjectorMs: b.getUint16(9, Endian.little) / 100.0,
    batteryV: b.getUint16(11, Endian.little) / 1000.0,
    gasInjectorMs: [
      for (var i = 0; i < n; i++) b.getUint16(14 + 2 * i, Endian.little) / 100.0
    ],
  );
}

int _u16(double v) => v.round().clamp(0, 65535).toInt();
int _i16(double v) => v.round().clamp(-32768, 32767).toInt();

Uint8List encodeTelemetry(Telemetry t) {
  final n = t.gasInjectorMs.length;
  final b = ByteData(14 + 2 * n);
  b.setUint16(0, _u16(t.gasMapKpa * 10), Endian.little);
  b.setUint16(2, _u16(t.manifoldMapKpa * 10), Endian.little);
  b.setInt16(4, _i16(t.reducerTempC * 10), Endian.little);
  b.setUint16(6, t.rpm.clamp(0, 65535).toInt(), Endian.little);
  b.setUint8(8, switch (t.mode) {
    FuelMode.petrol => 0,
    FuelMode.gas => 1,
    FuelMode.switching => 2,
    FuelMode.unknown => 255,
  });
  b.setUint16(9, _u16(t.petrolInjectorMs * 100), Endian.little);
  b.setUint16(11, _u16(t.batteryV * 1000), Endian.little);
  b.setUint8(13, n);
  for (var i = 0; i < n; i++) {
    b.setUint16(14 + 2 * i, _u16(t.gasInjectorMs[i] * 100), Endian.little);
  }
  return buildFrame(Cmd.telemetry, b.buffer.asUint8List());
}

/// DTC payload: u8 count, then count x u16 (little endian).
List<int> decodeDtcList(Uint8List p) {
  if (p.isEmpty) return const [];
  final n = p[0];
  if (p.length < 1 + 2 * n) return const [];
  final b = ByteData.sublistView(p);
  return [for (var i = 0; i < n; i++) b.getUint16(1 + 2 * i, Endian.little)];
}

Uint8List encodeDtcList(List<int> codes) {
  final b = ByteData(1 + 2 * codes.length)..setUint8(0, codes.length);
  for (var i = 0; i < codes.length; i++) {
    b.setUint16(1 + 2 * i, codes[i], Endian.little);
  }
  return buildFrame(Cmd.dtcList, b.buffer.asUint8List());
}
