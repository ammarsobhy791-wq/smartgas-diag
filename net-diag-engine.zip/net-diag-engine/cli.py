#!/usr/bin/env python3
"""net-diag-engine: Rich CLI for PMTU, path and latency diagnostics."""
from __future__ import annotations

import argparse
import sys
from typing import Callable, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import (BarColumn, Progress, SpinnerColumn, TaskProgressColumn,
                           TextColumn, TimeElapsedColumn)
from rich.prompt import Prompt
from rich.table import Table

from core.advisor import build_report
from core.models import DiagnosticReport, PathResult, PMTUResult, ProbeStatus
from core.path_analyzer import PathAnalyzer
from core.pmtu_scanner import PMTUScanner
from core.utils import is_privileged
from reporter import save_reports

OK, WARN, BAD, SILENT = "[green]✔[/]", "[yellow]⚠[/]", "[red]✖[/]", "[dim]·[/]"
COLOR = {"healthy": "green", "warning": "yellow", "critical": "red"}
EXIT = {"healthy": 0, "warning": 1, "critical": 2}


# ------------------------------------------------------------------ arguments
def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("target", help="hostname or IPv4 address")
    common.add_argument("--timeout", type=float, default=2.0, help="per-probe timeout in seconds (default 2.0)")
    common.add_argument("--max-hops", type=int, default=30, help="maximum TTL (default 30)")
    common.add_argument("--json", metavar="FILE", help="write JSON report")
    common.add_argument("--text", metavar="FILE", help="write text report")
    common.add_argument("--html", metavar="FILE", help="write HTML report")

    mtu = argparse.ArgumentParser(add_help=False)
    mtu.add_argument("--min-mtu", type=int, default=576)
    mtu.add_argument("--max-mtu", type=int, default=1500, help="use 9000 to test jumbo frames")
    mtu.add_argument("--retries", type=int, default=2, help="retries per silent probe (default 2)")
    mtu.add_argument("--no-locate", action="store_true", help="skip blackhole localisation")

    path = argparse.ArgumentParser(add_help=False)
    path.add_argument("--probes", type=int, default=5, help="probes per hop (default 5)")
    path.add_argument("--packet-size", type=int, default=64, help="probe size in bytes (default 64)")
    path.add_argument("--no-dns", action="store_true", help="skip reverse DNS lookups")

    parser = argparse.ArgumentParser(prog="net-diag-engine",
                                     description="Diagnose path issues, latency bottlenecks and PMTUD blackholes.")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("pmtu", parents=[common, mtu], help="Path MTU discovery & blackhole detection")
    sub.add_parser("path", parents=[common, path], help="Hop-by-hop latency/loss analysis")
    sub.add_parser("full", parents=[common, mtu, path], help="Run both diagnostics")
    sub.add_parser("interactive", help="Guided prompts")
    return parser


def interactive(console: Console, parser: argparse.ArgumentParser) -> argparse.Namespace:
    console.print(Panel("Choose a diagnostic and enter a target.", title="Interactive mode", border_style="cyan"))
    cmd = Prompt.ask("Diagnostic", choices=["pmtu", "path", "full"], default="full")
    target = Prompt.ask("Target host or IPv4")
    return parser.parse_args([cmd, target])


# ------------------------------------------------------------------ rendering
def make_progress(console: Console) -> Progress:
    return Progress(SpinnerColumn(), TextColumn("[bold cyan]{task.description}"), BarColumn(),
                    TaskProgressColumn(), TimeElapsedColumn(), console=console, transient=True)


def with_progress(console: Console, label: str, work: Callable[[Callable[[int, int, str], None]], object]):
    with make_progress(console) as progress:
        task = progress.add_task(label, total=None)

        def cb(done: int, total: int, desc: str) -> None:
            progress.update(task, description=desc, total=total, completed=min(done, total))

        return work(cb)


def render_pmtu(console: Console, r: PMTUResult) -> None:
    table = Table(title=f"PMTU probes → {r.target_ip}", header_style="bold")
    for col, kw in (("#", {"justify": "right"}), ("Packet size", {"justify": "right"}),
                    ("", {}), ("Result", {}), ("Detail", {})):
        table.add_column(col, **kw)
    for i, p in enumerate(r.probes, 1):
        detail = p.reporter or p.note or ""
        if p.next_hop_mtu:
            detail = f"{p.reporter} advertises next-hop MTU {p.next_hop_mtu}"
        elif p.status == ProbeStatus.OK and p.rtt_ms:
            detail = f"{p.rtt_ms:.1f} ms"
        icon, label = {
            ProbeStatus.OK: (OK, "Delivered"),
            ProbeStatus.FRAG_NEEDED: (WARN, "Fragmentation needed"),
            ProbeStatus.LOCAL_TOO_BIG: (WARN, "Exceeds local MTU"),
            ProbeStatus.TIMEOUT: (BAD, "Silent drop"),
        }.get(p.status, (BAD, p.status.value))
        table.add_row(str(i), f"{p.size} B", icon, label, detail)
    console.print(table)

    color = {"ok": "green", "reduced": "yellow", "blackhole": "red", "unreachable": "red"}.get(r.status, "white")
    lines = [f"[bold]Status:[/] [{color}]{r.status.upper()}[/]"]
    if r.pmtu:
        lines.append(f"[bold]Path MTU:[/] {r.pmtu} bytes   [bold]TCP MSS:[/] {r.recommended_mss}")
    if r.blackhole_location:
        b = r.blackhole_location
        lines.append(f"[bold red]Blackhole:[/] after hop {b['after_hop']} ({b['after_ip'] or '?'}) "
                     f"→ before hop {b['before_hop']} ({b['before_ip'] or '?'})")
    lines += [f"[dim]{n}[/]" for n in r.notes]
    console.print(Panel("\n".join(lines), title="PMTU summary", border_style=color))


def render_path(console: Console, r: PathResult) -> None:
    table = Table(title=f"Path to {r.target} ({r.target_ip})", header_style="bold")
    for col, right in (("Hop", True), ("", False), ("Address", False), ("Host", False), ("Loss", True),
                       ("Min", True), ("Avg", True), ("Max", True), ("Jitter", True)):
        table.add_column(col, justify="right" if right else "left", overflow="ellipsis", max_width=36)
    fmt = lambda v: "-" if v is None else f"{v:.1f}"
    for h in r.hops:
        icon = {"ok": OK, "warning": WARN, "critical": BAD}.get(h.status, SILENT)
        lc = "green" if h.loss_pct == 0 else "yellow" if h.loss_pct < 10 else "red"
        addr = h.ip or "*" + (f" (+{len(h.other_ips)})" if h.other_ips else "")
        if h.ip and h.other_ips:
            addr += f" (+{len(h.other_ips)})"
        table.add_row(str(h.ttl), icon, addr, h.hostname or "", f"[{lc}]{h.loss_pct:.0f}%[/]",
                      fmt(h.min_ms), fmt(h.avg_ms), fmt(h.max_ms), fmt(h.jitter_ms))
    console.print(table)


def render_summary(console: Console, report: DiagnosticReport) -> None:
    color = COLOR[report.overall_status]
    icons = {"info": OK, "warning": WARN, "critical": BAD}
    body = "\n".join(f"{icons[f.severity]} [bold]{f.title}[/]\n   [dim]{f.detail}[/]" for f in report.findings)
    console.print(Panel(body, title=f"Diagnostic summary: [{color}]{report.overall_status.upper()}[/]",
                        border_style=color))
    recs = "\n".join(f"[cyan]{i}.[/] {r}" for i, r in enumerate(report.recommendations, 1))
    console.print(Panel(recs, title="Recommendations", border_style="cyan"))


# ----------------------------------------------------------------------- main
def main(argv: Optional[list[str]] = None) -> int:
    parser, console = build_parser(), Console()
    args = parser.parse_args(argv)
    console.print(Panel.fit("[bold cyan]net-diag-engine[/]  PMTU · Path · Latency diagnostics", border_style="cyan"))

    if args.command in (None, "interactive"):
        args = interactive(console, parser)

    if not is_privileged():
        console.print(Panel("Raw sockets are required for ICMP probing.\n"
                            "Re-run with [bold]sudo[/] (Linux/macOS) or from an Administrator shell (Windows).",
                            title="Insufficient privileges", border_style="red"))
        return 3

    pmtu: Optional[PMTUResult] = None
    path: Optional[PathResult] = None
    try:
        if args.command in ("pmtu", "full"):
            pmtu = with_progress(console, "PMTU discovery", lambda cb: PMTUScanner(
                args.target, min_mtu=args.min_mtu, max_mtu=args.max_mtu, timeout=args.timeout,
                retries=args.retries, max_hops=args.max_hops,
                locate_blackholes=not args.no_locate, progress=cb).scan())
            render_pmtu(console, pmtu)
        if args.command in ("path", "full"):
            path = with_progress(console, "Tracing path", lambda cb: PathAnalyzer(
                args.target, max_hops=args.max_hops, probes=args.probes, timeout=min(args.timeout, 2.0),
                packet_size=args.packet_size, resolve_dns=not args.no_dns, progress=cb).run())
            render_path(console, path)
    except ValueError as exc:
        console.print(Panel(str(exc), title="Error", border_style="red"))
        return 3
    except PermissionError:
        console.print(Panel("Permission denied opening a raw socket. Use sudo/Administrator.",
                            title="Error", border_style="red"))
        return 3
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/]")
        return 130

    report = build_report(args.target, pmtu, path)
    render_summary(console, report)
    for p in save_reports(report, args.json, args.text, args.html):
        console.print(f"[green]✔[/] Saved report: {p}")
    return EXIT[report.overall_status]


if __name__ == "__main__":
    sys.exit(main())
