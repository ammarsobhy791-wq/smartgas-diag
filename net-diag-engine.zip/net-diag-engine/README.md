# net-diag-engine

A Python toolkit for diagnosing path issues, latency bottlenecks and **PMTUD blackholes**, with a Rich terminal UI.

## Features
- **PMTU scanner** (`core/pmtu_scanner.py`): DF-bit ICMP probes + binary search for the largest working MTU. Uses next-hop MTU hints from routers when present. Detects silent drops (blackholes) and pinpoints the link with a TTL sweep.
- **Path analyzer** (`core/path_analyzer.py`): per-hop loss %, min/avg/max RTT and jitter. Separates real bottlenecks from ICMP rate limiting by checking whether loss/latency persists on later hops.
- **Reporter** (`reporter.py`): JSON, plain text and self-contained HTML (light/dark aware).
- **CLI** (`cli.py`): progress bars, styled tables with status icons, summary and recommendation panels.

## Setup
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
Python 3.9+. IPv4 only. Windows also needs [Npcap](https://npcap.com).

## Privileges
ICMP probing uses raw sockets, so run as root/Administrator:
```bash
sudo .venv/bin/python cli.py full example.com    # use the venv's python under sudo
```
Linux alternative: `sudo setcap cap_net_raw+ep $(readlink -f .venv/bin/python)` (then no sudo needed).

## Usage
```bash
python cli.py pmtu 203.0.113.10                       # MTU discovery + blackhole location
python cli.py pmtu host --max-mtu 9000                # test jumbo frames
python cli.py path example.com --probes 10 --no-dns   # hop-by-hop latency/loss
python cli.py full example.com --json out.json --html out.html --text out.txt
python cli.py                                         # interactive prompts
```
Exit codes: `0` healthy, `1` warnings, `2` critical, `3` usage/privilege/resolution error, `130` interrupted. Handy in scripts and CI.

## How blackholes are detected
1. A small packet (default 576 B) gets a reply, so the target is reachable.
2. Larger DF packets time out and **no** ICMP type 3 code 4 ever arrives.
3. A TTL sweep sends a small and a large packet per hop. The hop after which only the small packet is answered marks the link where large packets are lost.

## Limitations
- Results depend on the target and routers answering ICMP. Filtered ICMP means "unreachable", not necessarily "broken".
- The OS may refuse packets above the local interface MTU; these are reported as "Exceeds local MTU".
- Per-hop loss on a single router is often ICMP rate limiting; judge by whether it persists downstream.
- ECMP paths may show several addresses per hop (`+N`).

## Layout
```
net-diag-engine/
├── cli.py            # Rich CLI
├── reporter.py       # JSON / text / HTML output
├── requirements.txt
├── README.md
└── core/
    ├── models.py         # dataclasses
    ├── utils.py          # privilege check, DNS
    ├── pmtu_scanner.py   # PMTU + blackhole logic
    ├── path_analyzer.py  # hop analysis + bottleneck heuristics
    └── advisor.py        # findings & recommendations
```
