"""Shared data models used by the scanners, advisor and reporter."""
from __future__ import annotations

import datetime as dt
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Optional


class ProbeStatus(str, Enum):
    OK = "ok"                        # ICMP echo reply received
    FRAG_NEEDED = "frag_needed"      # ICMP type 3 code 4 from a router
    LOCAL_TOO_BIG = "local_too_big"  # rejected by the local interface MTU
    TIMEOUT = "timeout"              # silence (possible PMTUD blackhole)
    TTL_EXCEEDED = "ttl_exceeded"    # ICMP type 11 from an intermediate hop
    UNREACHABLE = "unreachable"      # other ICMP type 3
    ERROR = "error"


@dataclass
class ProbeResult:
    size: int
    status: ProbeStatus
    ttl: int = 64
    reporter: Optional[str] = None
    next_hop_mtu: Optional[int] = None
    rtt_ms: Optional[float] = None
    note: str = ""


@dataclass
class PMTUResult:
    target: str
    target_ip: str
    min_mtu: int
    max_mtu: int
    pmtu: Optional[int] = None
    recommended_mss: Optional[int] = None
    status: str = "unknown"  # ok | reduced | blackhole | unreachable
    blackhole_location: Optional[dict[str, Any]] = None
    probes: list[ProbeResult] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


@dataclass
class HopStat:
    ttl: int
    ip: Optional[str] = None
    hostname: Optional[str] = None
    other_ips: list[str] = field(default_factory=list)  # e.g. ECMP paths
    sent: int = 0
    received: int = 0
    loss_pct: float = 0.0
    min_ms: Optional[float] = None
    avg_ms: Optional[float] = None
    max_ms: Optional[float] = None
    jitter_ms: Optional[float] = None
    reached: bool = False
    status: str = "ok"  # ok | warning | critical | silent


@dataclass
class PathResult:
    target: str
    target_ip: str
    probes_per_hop: int
    hops: list[HopStat] = field(default_factory=list)
    reached: bool = False


@dataclass
class Finding:
    severity: str  # info | warning | critical
    title: str
    detail: str
    hop: Optional[int] = None


@dataclass
class DiagnosticReport:
    target: str
    target_ip: str
    pmtu: Optional[PMTUResult] = None
    path: Optional[PathResult] = None
    findings: list[Finding] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    generated_at: str = field(
        default_factory=lambda: dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    )

    @property
    def overall_status(self) -> str:
        severities = {f.severity for f in self.findings}
        if "critical" in severities:
            return "critical"
        if "warning" in severities:
            return "warning"
        return "healthy"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["overall_status"] = self.overall_status
        return data
