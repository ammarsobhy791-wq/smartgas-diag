"""Hop-by-hop path analysis: RTT, jitter and loss per hop, plus bottleneck detection."""
from __future__ import annotations

import random
import statistics
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Optional

from scapy.all import ICMP, IP, Raw, sr

from .models import Finding, HopStat, PathResult
from .utils import resolve_target, reverse_dns

ProgressCB = Callable[[int, int, str], None]
_RANK = {"ok": 0, "silent": 0, "warning": 1, "critical": 2}


class PathAnalyzer:
    def __init__(
        self,
        target: str,
        *,
        max_hops: int = 30,
        probes: int = 5,
        timeout: float = 1.5,
        packet_size: int = 64,
        resolve_dns: bool = True,
        max_silent: int = 6,
        progress: Optional[ProgressCB] = None,
    ) -> None:
        self.target = target
        self.target_ip = resolve_target(target)
        self.max_hops, self.probes, self.timeout = max_hops, probes, timeout
        self.packet_size, self.resolve_dns = packet_size, resolve_dns
        self.max_silent, self.progress = max_silent, progress
        self._ident = random.randint(1, 0xFFFF)

    def run(self) -> PathResult:
        result = PathResult(self.target, self.target_ip, self.probes)
        silent_run = 0
        for ttl in range(1, self.max_hops + 1):
            hop = self._probe_hop(ttl)
            result.hops.append(hop)
            if self.progress:
                self.progress(ttl, self.max_hops, f"Probing hop {ttl}: {hop.ip or '*'}")
            if hop.reached:
                result.reached = True
                break
            silent_run = silent_run + 1 if hop.received == 0 else 0
            if silent_run >= self.max_silent:
                break
        if self.resolve_dns:
            self._resolve_names(result.hops)
        if self.progress:
            self.progress(1, 1, "Analysing results")
        analyze(result)
        return result

    def _probe_hop(self, ttl: int) -> HopStat:
        payload = Raw(load=b"\x00" * max(self.packet_size - 28, 0))
        pkts = [IP(dst=self.target_ip, ttl=ttl)
                / ICMP(id=self._ident, seq=ttl * 64 + i) / payload
                for i in range(self.probes)]
        answered, _ = sr(pkts, timeout=self.timeout, inter=0.03, verbose=0)

        rtts: list[float] = []
        ips: Counter[str] = Counter()
        reached = False
        for snd, rcv in answered:
            if not rcv.haslayer(ICMP):
                continue
            rtts.append((rcv.time - snd.sent_time) * 1000)
            ips[rcv[IP].src] += 1
            t = rcv[ICMP].type
            if t == 0 or (t == 3 and rcv[IP].src == self.target_ip):
                reached = True

        hop = HopStat(ttl=ttl, sent=self.probes, received=len(rtts), reached=reached)
        hop.loss_pct = round((hop.sent - hop.received) / hop.sent * 100, 1)
        if ips:
            common = ips.most_common()
            hop.ip, hop.other_ips = common[0][0], [ip for ip, _ in common[1:]]
        if rtts:
            hop.min_ms, hop.max_ms = round(min(rtts), 2), round(max(rtts), 2)
            hop.avg_ms = round(statistics.fmean(rtts), 2)
            hop.jitter_ms = round(statistics.pstdev(rtts), 2) if len(rtts) > 1 else 0.0
        else:
            hop.status = "silent"
        return hop

    @staticmethod
    def _resolve_names(hops: list[HopStat]) -> None:
        pool = ThreadPoolExecutor(max_workers=8)
        futures = {h.ttl: pool.submit(reverse_dns, h.ip) for h in hops if h.ip}
        for hop in hops:
            fut = futures.get(hop.ttl)
            if fut:
                try:
                    hop.hostname = fut.result(timeout=3)
                except Exception:
                    hop.hostname = None
        pool.shutdown(wait=False, cancel_futures=True)


def analyze(
    result: PathResult,
    *,
    latency_jump_ms: float = 50.0,
    loss_threshold: float = 10.0,
    jitter_threshold_ms: float = 30.0,
) -> list[Finding]:
    """Annotate hops with a status and return findings.

    Loss/latency at one hop only counts as a real bottleneck if it persists on
    the hops after it; otherwise it is most likely ICMP rate-limiting or
    control-plane deprioritisation on that router.
    """
    findings: list[Finding] = []
    hops = result.hops

    def mark(hop: HopStat, level: str) -> None:
        if _RANK[level] > _RANK[hop.status]:
            hop.status = level

    prev_avg: Optional[float] = None
    for i, hop in enumerate(hops):
        if hop.received == 0:
            hop.status = "silent"
            continue
        later = [h for h in hops[i + 1:] if h.received > 0]

        if hop.loss_pct >= loss_threshold:
            persistent = all(h.loss_pct >= hop.loss_pct / 2 for h in later)
            if persistent:
                level = "critical" if hop.loss_pct >= 50 else "warning"
                mark(hop, level)
                findings.append(Finding(level, f"Packet loss from hop {hop.ttl}",
                    f"{hop.loss_pct:.0f}% loss at {hop.ip} that persists on later hops: "
                    "likely a congested or faulty link at or just after this hop.", hop.ttl))
            else:
                findings.append(Finding("info", f"ICMP rate limiting at hop {hop.ttl}",
                    f"{hop.loss_pct:.0f}% loss at {hop.ip} but later hops are clean, so "
                    "forwarding is unaffected (router deprioritises ICMP replies).", hop.ttl))

        if prev_avg is not None and hop.avg_ms is not None:
            delta = hop.avg_ms - prev_avg
            if delta >= latency_jump_ms:
                persists = all(h.avg_ms is not None and h.avg_ms >= hop.avg_ms - delta * 0.5
                               for h in later)
                if persists:
                    mark(hop, "warning")
                    findings.append(Finding("warning", f"Latency bottleneck at hop {hop.ttl}",
                        f"RTT jumps +{delta:.0f} ms at {hop.ip} and stays high afterwards "
                        "(long-haul link, congestion or queueing).", hop.ttl))
                else:
                    findings.append(Finding("info", f"Transient latency spike at hop {hop.ttl}",
                        f"+{delta:.0f} ms at {hop.ip} but later hops recover; "
                        "likely control-plane delay, not a path problem.", hop.ttl))
        if hop.avg_ms is not None:
            prev_avg = hop.avg_ms

        if (hop.jitter_ms or 0) >= jitter_threshold_ms and hop.avg_ms:
            mark(hop, "warning")
            findings.append(Finding("warning", f"High jitter at hop {hop.ttl}",
                f"RTT standard deviation {hop.jitter_ms:.0f} ms at {hop.ip}.", hop.ttl))

    if not result.reached:
        last = next((h for h in reversed(hops) if h.received > 0), None)
        where = f"last responding hop: {last.ip} (hop {last.ttl})" if last else "no hop responded"
        findings.append(Finding("warning", "Destination not reached",
            f"The target did not answer within the hop limit; {where}. It may filter ICMP "
            "or the path may be broken beyond that point."))
    else:
        end = hops[-1]
        findings.append(Finding("info", "Destination reached",
            f"{result.target_ip} reached in {end.ttl} hops, avg RTT {end.avg_ms} ms, "
            f"loss {end.loss_pct:.0f}%."))
    return findings
