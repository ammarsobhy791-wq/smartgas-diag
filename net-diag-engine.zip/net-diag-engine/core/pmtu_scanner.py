"""Path MTU discovery via DF-bit ICMP probes and binary search.

Algorithm
---------
1. Baseline probe at ``min_mtu`` - proves the target answers ICMP at all.
2. Probe ``max_mtu``. If it passes, the path supports the full MTU.
3. Otherwise binary-search between the last good and first bad size. When a
   router answers "fragmentation needed" (ICMP 3/4) with a next-hop MTU, that
   value is tried first to converge faster.
4. If large probes are *silently* dropped (no ICMP 3/4 ever arrives) while
   small ones pass, the path is a PMTUD blackhole. A TTL-limited sweep with a
   small and a large packet then pinpoints the link where large packets vanish.
"""
from __future__ import annotations

import errno
import math
import random
import time
from typing import Callable, Optional

from scapy.all import ICMP, IP, Raw, sr1

from .models import PMTUResult, ProbeResult, ProbeStatus
from .utils import resolve_target

IP_ICMP_OVERHEAD = 28  # 20 byte IPv4 header + 8 byte ICMP header
TCP_IP_OVERHEAD = 40   # for MSS calculation

ProgressCB = Callable[[int, int, str], None]


def _classify(size: int, ttl: int, resp, rtt_ms: float) -> ProbeResult:
    if resp is None:
        return ProbeResult(size, ProbeStatus.TIMEOUT, ttl)
    if resp.haslayer(ICMP):
        icmp, reporter = resp[ICMP], resp[IP].src
        if icmp.type == 0:
            return ProbeResult(size, ProbeStatus.OK, ttl, reporter, rtt_ms=rtt_ms)
        if icmp.type == 3 and icmp.code == 4:
            hint = int(getattr(icmp, "nexthopmtu", 0) or 0) or None
            return ProbeResult(size, ProbeStatus.FRAG_NEEDED, ttl, reporter, hint, rtt_ms)
        if icmp.type == 3:
            return ProbeResult(size, ProbeStatus.UNREACHABLE, ttl, reporter,
                               note=f"ICMP unreachable code {icmp.code}")
        if icmp.type == 11:
            return ProbeResult(size, ProbeStatus.TTL_EXCEEDED, ttl, reporter, rtt_ms=rtt_ms)
    return ProbeResult(size, ProbeStatus.ERROR, ttl, note="Unexpected reply")


def _responded(p: ProbeResult) -> bool:
    return p.status in (ProbeStatus.OK, ProbeStatus.TTL_EXCEEDED)


class PMTUScanner:
    def __init__(
        self,
        target: str,
        *,
        min_mtu: int = 576,
        max_mtu: int = 1500,
        timeout: float = 2.0,
        retries: int = 2,
        max_hops: int = 30,
        locate_blackholes: bool = True,
        progress: Optional[ProgressCB] = None,
    ) -> None:
        if not 68 <= min_mtu < max_mtu <= 65535:
            raise ValueError("Require 68 <= min_mtu < max_mtu <= 65535")
        self.target = target
        self.target_ip = resolve_target(target)
        self.min_mtu, self.max_mtu = min_mtu, max_mtu
        self.timeout, self.retries, self.max_hops = timeout, retries, max_hops
        self.locate_blackholes = locate_blackholes
        self.progress = progress
        self._ident = random.randint(1, 0xFFFF)
        self._seq = 0
        self._done = 0
        self._total = math.ceil(math.log2(max_mtu - min_mtu + 1)) + 3

    # ------------------------------------------------------------------ probes
    def _tick(self, desc: str) -> None:
        self._done += 1
        if self.progress:
            self.progress(self._done, self._total, desc)

    def _probe_once(self, size: int, ttl: int, timeout: float) -> ProbeResult:
        self._seq = (self._seq + 1) & 0xFFFF
        payload = b"\x00" * max(size - IP_ICMP_OVERHEAD, 0)
        pkt = (IP(dst=self.target_ip, ttl=ttl, flags="DF")
               / ICMP(id=self._ident, seq=self._seq) / Raw(load=payload))
        start = time.perf_counter()
        try:
            resp = sr1(pkt, timeout=timeout, verbose=0)
        except PermissionError:
            raise
        except OSError as exc:
            if exc.errno == errno.EMSGSIZE:
                return ProbeResult(size, ProbeStatus.LOCAL_TOO_BIG, ttl,
                                   note="Exceeds local interface MTU")
            return ProbeResult(size, ProbeStatus.ERROR, ttl, note=str(exc))
        except Exception as exc:  # scapy internals
            return ProbeResult(size, ProbeStatus.ERROR, ttl, note=str(exc))
        return _classify(size, ttl, resp, (time.perf_counter() - start) * 1000)

    def _send(self, size: int, ttl: int = 64, retries: Optional[int] = None,
              timeout: Optional[float] = None) -> ProbeResult:
        attempts = (self.retries if retries is None else retries) + 1
        result = None
        for _ in range(attempts):
            result = self._probe_once(size, ttl, timeout or self.timeout)
            if result.status != ProbeStatus.TIMEOUT:
                break
        return result  # type: ignore[return-value]

    def _test(self, res: PMTUResult, size: int, label: str) -> ProbeResult:
        probe = self._send(size)
        res.probes.append(probe)
        self._tick(f"{label}: {size} bytes")
        return probe

    # -------------------------------------------------------------------- scan
    def scan(self) -> PMTUResult:
        res = PMTUResult(self.target, self.target_ip, self.min_mtu, self.max_mtu)

        base = self._test(res, self.min_mtu, "Baseline")
        if base.status != ProbeStatus.OK:
            res.status = "unreachable"
            res.notes.append(
                f"No echo reply at {self.min_mtu} bytes. The target may be down or "
                "filtering ICMP; PMTU cannot be measured with ICMP probes."
            )
            self._tick("Done")
            return res

        top = self._test(res, self.max_mtu, "Max MTU")
        if top.status == ProbeStatus.OK:
            res.pmtu, res.status = self.max_mtu, "ok"
            res.recommended_mss = self.max_mtu - TCP_IP_OVERHEAD
            res.notes.append(f"Path supports {self.max_mtu} bytes. Raise --max-mtu to test jumbo frames.")
            return res

        lo, hi = self.min_mtu, self.max_mtu  # lo = known good, hi = known bad
        hint = top.next_hop_mtu
        while hi - lo > 1:
            mid = hint if hint and lo < hint < hi else (lo + hi) // 2
            probe = self._test(res, mid, "Searching")
            if probe.status == ProbeStatus.OK:
                lo = mid
                hint = None
            else:
                hi = mid
                hint = probe.next_hop_mtu

        res.pmtu, res.recommended_mss = lo, lo - TCP_IP_OVERHEAD
        failed = [p for p in res.probes if p.size > lo]
        icmp_feedback = any(p.status in (ProbeStatus.FRAG_NEEDED, ProbeStatus.LOCAL_TOO_BIG)
                            for p in failed)
        silent = any(p.status == ProbeStatus.TIMEOUT for p in failed)

        if any(p.status == ProbeStatus.LOCAL_TOO_BIG for p in failed):
            res.notes.append("Result is limited by the local interface MTU (or the OS refused to send larger packets).")
        if silent and not icmp_feedback:
            res.status = "blackhole"
            res.notes.append(
                f"Packets > {lo} bytes are dropped silently while smaller ones pass and no ICMP "
                "'Fragmentation Needed' is returned: a PMTUD blackhole."
            )
            if self.locate_blackholes:
                res.blackhole_location = self._locate_blackhole(lo + 1, self.min_mtu)
        else:
            res.status = "reduced"
            reporters = {p.reporter for p in failed if p.status == ProbeStatus.FRAG_NEEDED and p.reporter}
            if reporters:
                res.notes.append("Routers signalling the limit: " + ", ".join(sorted(reporters)))
        return res

    # --------------------------------------------------------- blackhole locate
    def _locate_blackhole(self, bad_size: int, good_size: int) -> Optional[dict]:
        """TTL sweep with a small and a large DF packet; find where large ones vanish."""
        self._total += self.max_hops
        rows: list[tuple[int, ProbeResult, ProbeResult]] = []
        for ttl in range(1, self.max_hops + 1):
            small = self._send(good_size, ttl, retries=1, timeout=min(self.timeout, 1.0))
            big = self._send(bad_size, ttl, retries=1, timeout=min(self.timeout, 1.0))
            rows.append((ttl, small, big))
            self._tick(f"Locating blackhole: hop {ttl}")
            if small.status in (ProbeStatus.OK, ProbeStatus.UNREACHABLE):
                break
            if big.status == ProbeStatus.FRAG_NEEDED:  # a router finally told us
                return {"after_hop": ttl - 1, "after_ip": None, "before_hop": ttl,
                        "before_ip": big.reporter, "note": "Router reported fragmentation needed"}

        for i, (ttl, small, big) in enumerate(rows):
            if _responded(small) and not _responded(big) and not any(
                    _responded(b) for _, _, b in rows[i + 1:]):
                last_ok = next(((t, b.reporter) for t, _, b in reversed(rows[:i]) if _responded(b)),
                               (0, None))
                return {"after_hop": last_ok[0], "after_ip": last_ok[1],
                        "before_hop": ttl, "before_ip": small.reporter}
        return None
