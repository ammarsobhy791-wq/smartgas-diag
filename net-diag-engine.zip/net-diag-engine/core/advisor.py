"""Turns raw scan results into findings and actionable recommendations."""
from __future__ import annotations

from typing import Optional

from .models import DiagnosticReport, Finding, PathResult, PMTUResult
from .path_analyzer import analyze


def _pmtu_findings(p: PMTUResult, recs: list[str]) -> list[Finding]:
    mss = p.recommended_mss
    if p.status == "unreachable":
        recs.append("Confirm the target is up and permits ICMP echo; try the `path` command or a TCP-based test.")
        return [Finding("critical", "PMTU test impossible", p.notes[0] if p.notes else "No reply")]
    if p.status == "blackhole":
        loc = p.blackhole_location
        where = (f" Large packets disappear between hop {loc['after_hop']} ({loc['after_ip'] or '?'}) "
                 f"and hop {loc['before_hop']} ({loc['before_ip'] or '?'})." if loc else "")
        recs += [
            f"Clamp TCP MSS at the edge (e.g. `iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN "
            f"-j TCPMSS --set-mss {mss}`).",
            "Allow ICMP type 3 code 4 (Fragmentation Needed) through every firewall/ACL on the path.",
            "On affected Linux hosts enable PLPMTUD: `sysctl -w net.ipv4.tcp_mtu_probing=1`.",
            f"Alternatively lower the interface MTU to {p.pmtu}.",
        ]
        if loc:
            recs.append(f"Escalate to the operator of {loc['before_ip'] or 'the next hop'} with this report.")
        return [Finding("critical", "PMTUD blackhole detected",
                        f"Largest working packet is {p.pmtu} bytes; larger ones are dropped without ICMP feedback.{where}")]
    if p.status == "reduced":
        recs.append(f"Set TCP MSS to <= {mss} on tunnels/edge routers (path MTU is {p.pmtu}).")
        return [Finding("warning", "Path MTU below expected",
                        f"Path MTU is {p.pmtu} bytes (tested up to {p.max_mtu}). Typical causes: "
                        "PPPoE (1492), VPN/GRE/VXLAN overhead. ICMP feedback works, so PMTUD should cope.")]
    return [Finding("info", "Path MTU healthy", f"{p.pmtu} bytes end to end (MSS {mss}).")]


def build_report(target: str, pmtu: Optional[PMTUResult], path: Optional[PathResult]) -> DiagnosticReport:
    ref = pmtu or path
    assert ref is not None, "At least one result is required"
    report = DiagnosticReport(target=target, target_ip=ref.target_ip, pmtu=pmtu, path=path)
    recs: list[str] = []

    if pmtu:
        report.findings += _pmtu_findings(pmtu, recs)
    if path:
        found = analyze(path)  # idempotent; refreshes hop statuses
        report.findings += found
        if any(f.title.startswith("Latency bottleneck") for f in found):
            recs.append("Run a longer `mtr`/path test at different times of day and share it with the transit provider at the flagged hop.")
        if any(f.title.startswith("Packet loss from") for f in found):
            recs.append("Persistent loss: check for congestion/duplex errors on the flagged link, or open a ticket with its operator.")
        if any(f.title == "Destination not reached" for f in found):
            recs.append("If the target filters ICMP, test with TCP-based tools (e.g. `tcptraceroute`, `hping3 -S`).")

    if not recs:
        recs.append("No action required: the path looks healthy.")
    report.recommendations = list(dict.fromkeys(recs))
    return report
