"""Small helpers: privilege check, name resolution, reverse DNS."""
from __future__ import annotations

import ipaddress
import os
import socket
from typing import Optional


def is_privileged() -> bool:
    """True if the process may open raw sockets (root / Administrator)."""
    if os.name == "nt":
        try:
            import ctypes

            return bool(ctypes.windll.shell32.IsUserAnAdmin())  # type: ignore[attr-defined]
        except Exception:
            return False
    return os.geteuid() == 0


def resolve_target(target: str) -> str:
    """Return an IPv4 address for a hostname or IPv4 literal."""
    try:
        ipaddress.IPv4Address(target)
        return target
    except ValueError:
        pass
    try:
        infos = socket.getaddrinfo(target, None, socket.AF_INET)
    except socket.gaierror as exc:
        raise ValueError(f"Cannot resolve '{target}' to an IPv4 address: {exc}") from exc
    return infos[0][4][0]


def reverse_dns(ip: str) -> Optional[str]:
    try:
        return socket.gethostbyaddr(ip)[0]
    except (socket.herror, socket.gaierror, OSError):
        return None
