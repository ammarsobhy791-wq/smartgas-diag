"""Render a DiagnosticReport as JSON, plain text or a self-contained HTML page."""
from __future__ import annotations

import json
from html import escape
from pathlib import Path
from typing import Optional

from core.models import DiagnosticReport

_ICON = {"critical": "✖", "warning": "⚠", "info": "✔", "healthy": "✔"}


def _f(v, suffix="") -> str:
    return "-" if v is None else f"{v}{suffix}"


def to_json(report: DiagnosticReport) -> str:
    return json.dumps(report.to_dict(), indent=2, default=str)


def to_text(report: DiagnosticReport) -> str:
    L = [f"net-diag-engine report: {report.target} ({report.target_ip})",
         f"Generated: {report.generated_at}",
         f"Overall status: {report.overall_status.upper()}", ""]
    if report.pmtu:
        p = report.pmtu
        L += ["PATH MTU", "-" * 60,
              f"Status: {p.status}   Path MTU: {_f(p.pmtu)}   Recommended MSS: {_f(p.recommended_mss)}"]
        if p.blackhole_location:
            b = p.blackhole_location
            L.append(f"Blackhole between hop {b['after_hop']} ({b['after_ip']}) and hop {b['before_hop']} ({b['before_ip']})")
        L += [f"{'Size':>6}  {'Result':<14} Detail"]
        for pr in p.probes:
            detail = pr.reporter or pr.note
            if pr.next_hop_mtu:
                detail += f" (next-hop MTU {pr.next_hop_mtu})"
            L.append(f"{pr.size:>6}  {pr.status.value:<14} {detail}")
        L += [f"Note: {n}" for n in p.notes] + [""]
    if report.path:
        L += ["HOP-BY-HOP PATH", "-" * 60,
              f"{'Hop':>3}  {'Address':<16} {'Loss%':>6} {'Min':>8} {'Avg':>8} {'Max':>8} {'Jit':>7}  Status"]
        for h in report.path.hops:
            L.append(f"{h.ttl:>3}  {(h.ip or '*'):<16} {h.loss_pct:>6.1f} {_f(h.min_ms):>8} "
                     f"{_f(h.avg_ms):>8} {_f(h.max_ms):>8} {_f(h.jitter_ms):>7}  {h.status}")
        L.append("")
    L += ["FINDINGS", "-" * 60]
    L += [f"[{f.severity.upper()}] {f.title}: {f.detail}" for f in report.findings]
    L += ["", "RECOMMENDATIONS", "-" * 60]
    L += [f"{i}. {r}" for i, r in enumerate(report.recommendations, 1)]
    return "\n".join(L) + "\n"


_CSS = """
:root{--bg:#fff;--fg:#1a1d21;--muted:#5b6470;--card:#f5f6f8;--line:#dde1e6;--ok:#1a7f37;--warn:#9a6700;--bad:#cf222e}
@media (prefers-color-scheme:dark){:root{--bg:#0f1318;--fg:#e6e9ee;--muted:#98a2b0;--card:#181e26;--line:#2b3441;--ok:#3fb950;--warn:#d29922;--bad:#f85149}}
body{font:15px/1.5 system-ui,sans-serif;background:var(--bg);color:var(--fg);max-width:960px;margin:0 auto;padding:24px 16px}
h1{font-size:1.4rem;margin:0}h2{font-size:1.1rem;margin:28px 0 8px}.muted{color:var(--muted)}
.badge{display:inline-block;padding:2px 10px;border-radius:12px;font-weight:600;border:1px solid currentColor}
.healthy,.info,.ok{color:var(--ok)}.warning{color:var(--warn)}.critical{color:var(--bad)}
.wrap{overflow-x:auto}table{border-collapse:collapse;width:100%}
th,td{padding:6px 10px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}
th{color:var(--muted);font-weight:600}.card{background:var(--card);border-radius:8px;padding:10px 14px;margin:6px 0}
"""


def to_html(report: DiagnosticReport) -> str:
    e = escape
    out = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'>"
           f"<meta name='viewport' content='width=device-width,initial-scale=1'>"
           f"<title>net-diag-engine: {e(report.target)}</title><style>{_CSS}</style></head><body>",
           f"<h1>Network diagnostics: {e(report.target)} <span class='muted'>({e(report.target_ip)})</span></h1>",
           f"<p class='muted'>Generated {e(report.generated_at)} &middot; Overall "
           f"<span class='badge {report.overall_status}'>{e(report.overall_status.upper())}</span></p>",
           "<h2>Findings</h2>"]
    for f in report.findings:
        out.append(f"<div class='card'><b class='{f.severity}'>{_ICON[f.severity]} {e(f.title)}</b><br>{e(f.detail)}</div>")
    out.append("<h2>Recommendations</h2><ol>" + "".join(f"<li>{e(r)}</li>" for r in report.recommendations) + "</ol>")

    if report.pmtu:
        p = report.pmtu
        out.append(f"<h2>Path MTU</h2><p>Status <b>{e(p.status)}</b> &middot; Path MTU <b>{_f(p.pmtu)}</b> "
                   f"&middot; MSS <b>{_f(p.recommended_mss)}</b></p><div class='wrap'><table>"
                   "<tr><th>Size</th><th>Result</th><th>Detail</th></tr>")
        for pr in p.probes:
            cls = "ok" if pr.status.value == "ok" else ("warning" if pr.status.value == "frag_needed" else "critical")
            detail = pr.reporter or pr.note
            if pr.next_hop_mtu:
                detail += f" (next-hop MTU {pr.next_hop_mtu})"
            out.append(f"<tr><td>{pr.size}</td><td class='{cls}'>{e(pr.status.value)}</td><td>{e(detail)}</td></tr>")
        out.append("</table></div>")

    if report.path:
        out.append("<h2>Hop-by-hop path</h2><div class='wrap'><table><tr><th>Hop</th><th>Address</th><th>Host</th>"
                   "<th>Loss %</th><th>Min</th><th>Avg</th><th>Max</th><th>Jitter</th><th>Status</th></tr>")
        for h in report.path.hops:
            cls = {"ok": "ok", "warning": "warning", "critical": "critical"}.get(h.status, "muted")
            out.append(f"<tr><td>{h.ttl}</td><td>{e(h.ip or '*')}</td><td>{e(h.hostname or '')}</td>"
                       f"<td>{h.loss_pct:.1f}</td><td>{_f(h.min_ms)}</td><td>{_f(h.avg_ms)}</td>"
                       f"<td>{_f(h.max_ms)}</td><td>{_f(h.jitter_ms)}</td><td class='{cls}'>{e(h.status)}</td></tr>")
        out.append("</table></div>")
    out.append("</body></html>")
    return "".join(out)


def save_reports(report: DiagnosticReport, json_path: Optional[str] = None,
                 text_path: Optional[str] = None, html_path: Optional[str] = None) -> list[Path]:
    saved = []
    for path, render in ((json_path, to_json), (text_path, to_text), (html_path, to_html)):
        if path:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(render(report), encoding="utf-8")
            saved.append(p)
    return saved
